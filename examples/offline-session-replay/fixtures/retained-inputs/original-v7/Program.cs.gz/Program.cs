using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading;
using System.Text.Json;
using Nyrwvy.Generated;

// Synthetic provider/Git effects and deterministic test gates. The host owns
// no Team registry, admission lock, task handle, ledger or session controller.
sealed class Effects : NyC_30316131336339322D316337632D376166312D393662372D326439653332656465623762
{
 readonly JsonElement scenario;
 readonly AsyncLocal<string> requestLabel=new();
 readonly ConcurrentQueue<object> calls=new();
 readonly ConcurrentDictionary<string,ManualResetEventSlim> started=new();
 readonly ConcurrentDictionary<string,bool> acquired=new();
 readonly ConcurrentDictionary<long,ManualResetEventSlim> workers=new(),providers=new();
 readonly ManualResetEventSlim snapshotEntered=new(false),snapshotReleased=new(false),commitEntered=new(false),commitReleased=new(false),closeEntered=new(false),closeReleased=new(false),spawnEntered=new(false),spawnReleased=new(false),faultReleased=new(false),cleanupEntered=new(false),cleanupReleased=new(false);
 readonly ConcurrentDictionary<string,int> counts=new();
 public int Active,MaxActive,Opened,Closed;
 public readonly Exception BodyFault=new InvalidOperationException("ordinary worker fault"),CleanupFault,ReleaseFault;
 public Exception? CancellationFault;
 string Setting(string key)=>scenario.TryGetProperty(key,out var v)?v.GetString()!:"";
 readonly string control;
 public bool LocalCompleted,TerminalWritten; public string OutputFault="";
 public Effects(JsonElement scenario,string control){this.control=control;this.scenario=scenario;epochMode=true;additionalMode=true;Checkpoint("before-input");if(Setting("autoMember")=="true")snapshotReleased.Set();CleanupFault=Setting("cleanupFault")=="OCE"?new OperationCanceledException("cleanup OCE"):new InvalidOperationException("cleanup fault");ReleaseFault=Setting("releaseFault")=="OCE"?new OperationCanceledException("release OCE"):new InvalidOperationException("release fault");}
 public object[] Calls=>calls.ToArray();
 static ManualResetEventSlim Cell(ConcurrentDictionary<long,ManualResetEventSlim> map,long id)=>map.GetOrAdd(id,_=>new(false));
 public static void Observe(object value){lock(typeof(Effects)){Console.Error.WriteLine(JsonSerializer.Serialize(value));}}
 void Log(string op,params (string Name,object Value)[] args){var row=new {operation=op,request=requestLabel.Value,arguments=args.Select(a=>new {parameter=a.Name,value=new {value=a.Value}}).ToArray()};calls.Enqueue(row);Observe(row);}
 public void ReleaseGates(){snapshotReleased.Set();commitReleased.Set();spawnReleased.Set();closeReleased.Set();}
 public void InputEnded(){Observe(new {operation="input-eof"});if(Setting("releaseOn")=="eof")ReleaseGates();}
 public static void Check(bool yes,string message){if(!yes)throw new Exception(message);}
 static void Wait(ManualResetEventSlim cell,string label)=>Check(cell.Wait(TimeSpan.FromSeconds(10)),"barrier timeout: "+label);
 static void Cancelled(string label){Check(NyRuntime.Cancellation.Value.WaitHandle.WaitOne(TimeSpan.FromSeconds(10)),"barrier timeout: cancellation "+label);}
 public NyResult<NyUnit,NyStr> Open(){Log("open");Opened++;return NyResult<NyUnit,NyStr>.Ok(NyUnit.Value);}
 public NyUnit Close(NyUnit handle){Check(Active==0,"release requires joined provider workers");Log("close");Closed++;if(control=="double-close"){Log("close");Closed++;Observe(new {operation="duplicate-close",count=Closed});}if(Setting("releaseFault")!="")throw ReleaseFault;return NyUnit.Value;}
 public NyResult<NyUnit,NyStr> WorkspaceCreate(NyStr workspace,NyStr basis){Checkpoint("before-fresh-workspace");Log("workspaceCreate",("workspace",workspace.ToString()),("base",basis.ToString()));if(requestLabel.Value=="blocker"){spawnEntered.Set();Wait(spawnReleased,"spawn release");}return NyResult<NyUnit,NyStr>.Ok(NyUnit.Value);}
 public NyResult<NyUnit,NyStr> WorkspaceDiscard(NyStr workspace){Log("workspaceDiscard",("workspace",workspace.ToString()));return NyResult<NyUnit,NyStr>.Ok(NyUnit.Value);}
 public NyResult<NyStr,NyStr> Provider(long id,NyStr workspace,long previous)
 {
  Log("provider",("id",id.ToString()),("workspace",workspace.ToString()),("previous",previous.ToString()));
  int active=Interlocked.Increment(ref Active),old;
  while(active>(old=Volatile.Read(ref MaxActive))&&Interlocked.CompareExchange(ref MaxActive,active,old)!=old){}
  Cell(providers,id).Set();
  try{
   string kind=scenario.GetProperty("providers").TryGetProperty(id.ToString(),out var v)?v.GetString()!:"hold";
   if(kind=="fault")throw BodyFault;
   if(kind=="hold"){Cancelled("provider "+id);return NyResult<NyStr,NyStr>.Err("cancelled");}
   if(id==1&&Setting("kind")=="session")Wait(Cell(providers,2),"second turn provider overlap");
   return NyResult<NyStr,NyStr>.Ok("completed");
  }finally{Interlocked.Decrement(ref Active);Observe(new {operation="provider-ended",id,cancelled=NyRuntime.CancellationRequested});}
 }
 public NyUnit MemberClose(long id){Log("memberClose",("id",id.ToString()));return NyUnit.Value;}
 public NyResult<NyStr,NyStr> Snapshot(long id,NyStr workspace){Log("snapshot",("id",id.ToString()),("workspace",workspace.ToString()));snapshotEntered.Set();Wait(snapshotReleased,"snapshot release");Check(!NyRuntime.CancellationRequested,"determined Member snapshot stays protected");return NyResult<NyStr,NyStr>.Ok(Setting("snapshotCommit")==""?"commit"+id:Setting("snapshotCommit"));}
 public NyStr Checks(long id,NyStr commit){Log("checks",("id",id.ToString()),("commit",commit.ToString()));return "passed";}
 public NyResult<NyList<NyStr>,NyStr> Step(NyStr operation,NyStr patch)
 {
  string phase=operation.ToString();Log("step",("operation",phase),("patch",patch.ToString()));
  counts.AddOrUpdate(phase,1,(_,n)=>n+1);
  if(phase=="commit"){commitEntered.Set();var clock=System.Diagnostics.Stopwatch.StartNew();while(!System.IO.File.Exists(Setting("commitGateFile"))){Check(clock.ElapsedMilliseconds<10000,"external commit gate timeout");Thread.Sleep(5);}Observe(new {operation="external-gate-released"});}
  Observe(new {operation="protected-step",phase,cancelled=NyRuntime.CancellationRequested});
  if(phase is "commit" or "head" or "save"){PhysicalStep(phase,patch.ToString());if(phase=="commit")Checkpoint("after-commit");}
  Check(!NyRuntime.CancellationRequested,"protected synthetic Git tail sees a clear token");
  string[] values=phase switch {"paths-member"=>new[]{"a","b"},"paths-leader"=>new[]{"c"},"patch"=>new[]{Setting("patch")},"head"=>new[]{PhysicalHead()},_=>Array.Empty<string>()};
  return NyResult<NyList<NyStr>,NyStr>.Ok(NyList<NyStr>.Create(values.Select(x=>(NyStr)x).ToArray()));
 }
 public NyUnit Reply(NyStr label,NyStr record){Log("reply",("label",label.ToString()),("record",record.ToString()));
  if(label.ToString()=="terminal"&&Closed>0&&Active==0){LocalCompleted=true;Observe(new {operation="local-completed",report=record.ToString()});}
  if(label.ToString()=="@wire"||label.ToString()=="@wire-terminal"){
   string output=record.ToString();
   if(control=="wrong-id" && label.ToString()=="@wire") {using var json=JsonDocument.Parse(output);var id=json.RootElement.GetProperty("id").GetRawText();output=output.Replace("\"id\":"+id,"\"id\":\"wrong\"");Observe(new {operation="response-id-rewritten",before=record.ToString(),after=output});}
   var writeClock=System.Diagnostics.Stopwatch.StartNew();
   try{UnixPipe.Write(output);Observe(new {operation="response-written",terminal=label.ToString()=="@wire-terminal",line=output});if(label.ToString()=="@wire-terminal")TerminalWritten=true;}
   catch(Exception error){OutputFault=error.GetType().Name;Observe(new {operation="output-fault",type=OutputFault,message=error.Message,terminal=label.ToString()=="@wire-terminal",elapsedMs=writeClock.ElapsedMilliseconds,deadlineMs=UnixPipe.WriteDeadlineMs});if(control!="suppress-output-fault")throw;Observe(new {operation="output-fault-suppressed"});}
  }return NyUnit.Value;}
 public NyUnit Gate(NyStr raw)
 {
  string label=raw.ToString();
  if(label.StartsWith("request-start:"))requestLabel.Value=label[14..];
  if(label.StartsWith("enter:"))requestLabel.Value=label[6..];
  Log("gate",("label",label));
  if(label.StartsWith("request-start:")){
   string name=label[14..];started.GetOrAdd(name,_=>new(false)).Set();
   if(name=="cancelled"&&Setting("cancellation")=="throw"){Cancelled(name);try{NyRuntime.Cancellation.Value.ThrowIfCancellationRequested();}catch(OperationCanceledException error){CancellationFault=error;throw;}}
   if(name=="fault"){Wait(faultReleased,"fault release");throw BodyFault;}
  }
  else if(label.StartsWith("enter:"))acquired[label[6..]]=true;
  else if(label.StartsWith("queued:")){string name=label[7..];Wait(started.GetOrAdd(name,_=>new(false)),label);Check(!acquired.ContainsKey(name),"queued command acquired admission");}
  else if(label.StartsWith("command-cleanup:")){
   if(label=="command-cleanup:cancelled"&&Setting("cleanupFault")!=""){cleanupEntered.Set();Wait(cleanupReleased,"cleanup release");throw CleanupFault;}
  }
  else if(label.StartsWith("worker-entry:"))Check(Setting("autoMember")=="true"||WaitHandle.WaitAny(new[]{Cell(workers,long.Parse(label[13..])).WaitHandle,NyRuntime.Cancellation.Value.WaitHandle},TimeSpan.FromSeconds(10))!=WaitHandle.WaitTimeout,"barrier timeout: "+label);
  else if(label.StartsWith("provider")){long id=long.Parse(label[8..]);Cell(workers,id).Set();Wait(Cell(providers,id),label);}
  else if(label=="snapshot1")Wait(snapshotEntered,label);
  else if(label=="release1")snapshotReleased.Set();
  else if(label=="commit-held")Wait(commitEntered,label);
  else if(label=="commit-release")commitReleased.Set();
  else if(label=="close-held-worker"&&Setting("kind")=="session"){closeEntered.Set();Wait(closeReleased,"close release");}
  else if(label=="close-held")Wait(closeEntered,label);
  else if(label=="close-release")closeReleased.Set();
  else if(label=="spawn-held")Wait(spawnEntered,label);
  else if(label=="spawn-release")spawnReleased.Set();
  else if(label=="fault-release")faultReleased.Set();
  else if(label=="cleanup-held")Wait(cleanupEntered,label);
  else if(label=="cleanup-release")cleanupReleased.Set();
  else if(label.StartsWith("stop-join:"))Cell(workers,long.Parse(label[10..])).Set();
  return NyUnit.Value;
 }
 // Generic fixture storage: opaque keys mapped to SHA256 filenames. Flush the
 // replacement and containing directory before returning. No app journal policy.
 readonly AsyncLocal<string> effectIdentity=new();
 string StorageRoot=>System.IO.Path.GetFullPath(Setting("storageDir"));
 static string DigestText(string value)=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(value))).ToLowerInvariant();
 string StoragePath(string key)=>System.IO.Path.Combine(StorageRoot,DigestText(key)+".json");
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int open(string path,int flags);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int fsync(int fd);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int close(int fd);
 void AtomicWrite(string key,string value){
  System.IO.Directory.CreateDirectory(StorageRoot);
  string file=StoragePath(key),temporary=file+".tmp";
  using(var output=new System.IO.FileStream(temporary,System.IO.FileMode.Create,System.IO.FileAccess.Write,System.IO.FileShare.None)){
   var bytes=System.Text.Encoding.UTF8.GetBytes(value);output.Write(bytes);output.Flush(true);
  }
  System.IO.File.Move(temporary,file,true);
  int fd=open(StorageRoot,65536);Check(fd>=0,"open storage directory");
  try{Check(fsync(fd)==0,"fsync storage directory");}finally{Check(close(fd)==0,"close storage directory");}
 }
 public NyStr Digest(NyStr value)=>DigestText(value.ToString());
 public NyOption<NyStr> StorageRead(NyStr key){if(epochMode)EpochOwnerPath();
  string file=StoragePath(key.ToString());bool present=System.IO.File.Exists(file);
  Observe(new {operation="storage-read",key=key.ToString(),present});
  return present?NyOption<NyStr>.Some(epochMode?System.IO.File.ReadAllText(file):PhysicalRead(key.ToString(),System.IO.File.ReadAllText(file))):NyOption<NyStr>.None();
 }
 void Checkpoint(string phase){
  Observe(new {operation="journal-checkpoint",phase,cancelled=NyRuntime.CancellationRequested});
  if(Setting("crashWindow")!=phase)return;
  var clock=System.Diagnostics.Stopwatch.StartNew();
  while(!System.IO.File.Exists(Setting("journalGateFile"))){Check(clock.ElapsedMilliseconds<15000,"journal checkpoint gate timeout");Thread.Sleep(5);}
 }
 public NyUnit StorageWrite(NyStr key,NyStr value){
 if(epochMode)EpochOwnerPath();Check(!observationAdmission,"observation admission cannot write application storage");Check(key.ToString()!="registry/v1"&&!key.ToString().StartsWith("journal/v1/",StringComparison.Ordinal),"original application evidence immutable");
  string k=key.ToString(),v=value.ToString();
  Observe(new {operation="storage-write-attempt",key=k,value=v,cancelled=NyRuntime.CancellationRequested});
  if(k.StartsWith("outcome-receipt/",StringComparison.Ordinal))Checkpoint("before-outcome-receipt");
  if(k.StartsWith("outcome/",StringComparison.Ordinal))Checkpoint("after-effect");
  if(k=="registry/v1")Checkpoint(v.Contains("\"phase\":\"ready\"",StringComparison.Ordinal)?"before-registry-publication":v.Contains("\"phase\":\"pending\"",StringComparison.Ordinal)?"before-registry-intent":"before-registry-idle");
  if(k=="additional-registry/v1"){Checkpoint(v.Contains("\"phase\":\"pending\"",StringComparison.Ordinal)?"before-additional-registry-intent":"before-additional-registry-publication");PhysicalPrepare(v);}
 if(k.StartsWith("additional-journal/v1/",StringComparison.Ordinal))PhysicalPrepareJournal(v);
 if(k.StartsWith("epoch-disposition/v1/",StringComparison.Ordinal))Checkpoint("before-disposition-"+k.Substring(21));
 if(k.StartsWith("epoch/v1/",StringComparison.Ordinal))Checkpoint("before-"+k.Substring(9));
 if(k.StartsWith("additional/v1/",StringComparison.Ordinal)||k.StartsWith("additional-lineage/v1/",StringComparison.Ordinal))Checkpoint("before-additional-write-"+k);AtomicWrite(k,v);if(k.StartsWith("additional/v1/",StringComparison.Ordinal)||k.StartsWith("additional-lineage/v1/",StringComparison.Ordinal))Checkpoint("after-additional-write-"+k);if(k.StartsWith("epoch-disposition/v1/",StringComparison.Ordinal))Checkpoint("after-disposition-"+k.Substring(21));if(k.StartsWith("epoch/v1/",StringComparison.Ordinal))Checkpoint("after-"+k.Substring(9));if(k.StartsWith("additional-journal/v1/",StringComparison.Ordinal)&&v.Contains("\"state\":\"pending\"",StringComparison.Ordinal))Checkpoint("after-additional-journal-intent");if(k=="additional-registry/v1")Checkpoint(v.Contains("\"phase\":\"pending\"",StringComparison.Ordinal)?"after-additional-registry-intent":"after-additional-registry-publication");Observe(new {operation="storage-written",key=k,value=v,cancelled=NyRuntime.CancellationRequested});
  if(k=="registry/v1")Checkpoint(v.Contains("\"phase\":\"ready\"",StringComparison.Ordinal)?"after-registry-publication":v.Contains("\"phase\":\"pending\"",StringComparison.Ordinal)?"after-registry-intent":"after-registry-idle");
  if(k.StartsWith("journal/v1/",StringComparison.Ordinal)&&v.Contains("\"state\":\"pending\"",StringComparison.Ordinal))Checkpoint("after-intent");
  if(k.StartsWith("additional-journal/v1/",StringComparison.Ordinal)&&v.Contains("\"state\":\"done\"",StringComparison.Ordinal))Checkpoint("after-additional-journal-completion");
  return NyUnit.Value;
 }
 public NyUnit EffectIdentity(NyStr identity){effectIdentity.Value=identity.ToString();Observe(new {operation="effect-identity",identity=effectIdentity.Value});return NyUnit.Value;}
 // The fixture's synthetic effect ledger is independent of journal records.
 // Each durable row is the synthetic effect itself; inspection never mutates it.
 void PersistEffect(string phase,string patch){
  string file=StoragePath("synthetic-effects");
  var rows=System.IO.File.Exists(file)?JsonSerializer.Deserialize<List<Dictionary<string,string>>>(System.IO.File.ReadAllText(file))!:new();
  rows.Add(new(){{"identity",effectIdentity.Value??"unidentified"},{"phase",phase},{"patch",patch}});
  AtomicWrite("synthetic-effects",JsonSerializer.Serialize(rows));
  Observe(new {operation="effect-persisted",phase,identity=effectIdentity.Value??"unidentified",patch});
 }
 public NyStr EffectEvidence(NyStr identity)=>PhysicalEvidence(identity.ToString());
 NyStr SyntheticEvidence(NyStr identity){
  string file=StoragePath("synthetic-effects"),state="unknown",head="";
  if(Setting("evidence")!="unavailable"){
   var rows=System.IO.File.Exists(file)?JsonSerializer.Deserialize<List<Dictionary<string,string>>>(System.IO.File.ReadAllText(file))!:new();
   var found=rows.Where(x=>x["identity"]==identity.ToString()).ToArray();
   if(found.Length==0)state="absent";
   else if(found.Length==3&&found[0]["phase"]=="commit"&&found[1]["phase"]=="head"&&found[2]["phase"]=="save"){
    state="applied";head=found[2]["patch"];
   }else state="partial";
  }
  // Effect completion/HEAD cannot determine success versus cancellation.
  // Only a graph-written actual outcome receipt can recover that result.
  var evidence=JsonSerializer.Serialize(new {state,head});
  Observe(new {operation="effect-evidence",identity=identity.ToString(),state,head});return evidence;
 }

 public bool StorageEmpty(){bool empty=!System.IO.Directory.Exists(StorageRoot)||!System.IO.Directory.EnumerateFileSystemEntries(StorageRoot).Any();Observe(new {operation="storage-empty",empty});return empty;}

 // Example binding for one trusted writer, fenced Git mutation children and
 // intact storage. File flush is inherited; power-loss Git durability is not proved.
 sealed class GitState {
  public string Head {get;set;}=""; public string Symbolic {get;set;}="";
  public string Refs {get;set;}=""; public string Objects {get;set;}="";
  public string IndexBytes {get;set;}=""; public string IndexEntries {get;set;}="";
  public string Worktree {get;set;}="";
 }
 sealed class GitPlan {
  public string Version {get;set;}="3"; public string Identity {get;set;}="";
  public string Intent {get;set;}=""; public string Repository {get;set;}="";
  public string RepositoryId {get;set;}=""; public string Selected {get;set;}="";
  public string Tree {get;set;}=""; public string Patch {get;set;}="";
  public string Commit {get;set;}=""; public string CommitBytes {get;set;}="";
  public bool NoMutation {get;set;}
  public string ExpectedIndex {get;set;}=""; public string ExpectedWorktree {get;set;}="";
  public GitState Before {get;set;}=new();
 }
 // This is child observation, never an original request result. A retained active
 // launch may precede creation or outlive the parent. PID absence cannot clear it.
 sealed class GitChild {
  public string Version {get;set;}="1";public string State {get;set;}="active";
  public string Invocation {get;set;}="";public string Identity {get;set;}="";
  public string Repository {get;set;}="";public string RepositoryId {get;set;}="";
  public string[] Args {get;set;}=Array.Empty<string>();public string InputDigest {get;set;}="";
  public int? Pid {get;set;}public int? ExitCode {get;set;}
  public bool InputClosed {get;set;}public bool OutputDrained {get;set;}
  public string OwnerDigest {get;set;}="";
 }
 void GitChildGuard(){
  string file=StoragePath("physical-child/v1");if(!System.IO.File.Exists(file))return;
  var child=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(file))!;
  Check((child.Version=="1"||child.Version=="2")&&child.Repository==GitRoot&&child.RepositoryId==Setting("fixtureId")&&child.Invocation!=""&&child.Identity!="","Git child ownership");
  if(dispositionInspection&&child.State=="active")LoadJoin(child,System.IO.File.ReadAllText(file));
  else Check(child.State=="quiescent"&&child.Pid.HasValue&&child.ExitCode.HasValue&&child.InputClosed&&child.OutputDrained,"Git child launch unresolved; explicit disposition required");
  var plan=JsonSerializer.Deserialize<GitPlan>(System.IO.File.ReadAllText(StoragePath(PlanKey(child.Identity))))!;
  Check(plan.Version=="3"&&plan.Identity==child.Identity&&plan.Repository==child.Repository&&plan.RepositoryId==child.RepositoryId,"Git child/plan correlation");
  string[] expected=child.Args.FirstOrDefault() switch{
   "commit-tree"=>new[]{"commit-tree",plan.Tree,"-p",plan.Before.Head},
   "update-ref"=>new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head},
   "read-tree"=>new[]{"read-tree","--reset","-u",plan.Commit},
   _=>Array.Empty<string>()};
  Check(expected.Length!=0&&child.Args.SequenceEqual(expected)&&child.InputDigest==DigestText(child.Args[0]=="commit-tree"?child.Identity+"\n":""),"Git child arguments/intent");
 }
 async System.Threading.Tasks.Task<string> GitOutput(System.IO.StreamReader reader){
  var output=new System.Text.StringBuilder();var buffer=new char[4096];int count;
  while((count=await reader.ReadAsync(buffer))!=0){Check(output.Length+count<=1048576,"bounded Git output exceeded");output.Append(buffer,0,count);}
  return output.ToString();
 }
 string GitRoot=>System.IO.Path.Combine(System.IO.Path.GetDirectoryName(StorageRoot)!,"git");
 void GitGuard(){
  Check(Setting("fixtureId")!=""&&System.IO.File.ReadAllText(System.IO.Path.Combine(GitRoot,".git","offline-fixture-id"))==Setting("fixtureId"),"disposable repository identity");
  for(var directory=new System.IO.DirectoryInfo(GitRoot);directory!=null;directory=directory.Parent)Check(directory.LinkTarget==null,"symlinked fixture directory");
  Check(new System.IO.DirectoryInfo(System.IO.Path.Combine(GitRoot,".git")).LinkTarget==null,"symlinked Git directory");
  Check(!System.IO.File.Exists(System.IO.Path.Combine(GitRoot,".git","objects","info","alternates")),"external object store");
 }
 string Git(string[] args,string? input=null,bool mutation=false,bool trim=true){
  GitGuard();if(epochMode){EpochChildGuard();if(additionalMode)AdditionalChildGuard();}else GitChildGuard();
  Check(!dispositionInspection||!mutation,"disposition inspection cannot mutate Git");
  if(mutation&&epochMode){EpochOwnerPath();return OwnedGit(args,input,trim,EpochLaunchKey(args));}
  if(mutation&&Setting("gitOwner")!="")return OwnedGit(args,input,trim);
  int deadline=Setting("gitDeadlineMs")==""?10000:int.Parse(Setting("gitDeadlineMs"));Check(deadline>=250&&deadline<=10000,"bounded Git deadline");
  var start=new System.Diagnostics.ProcessStartInfo("git"){WorkingDirectory=GitRoot,UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
  foreach(var name in start.Environment.Keys.Where(x=>x.StartsWith("GIT_",StringComparison.Ordinal)).ToArray())start.Environment.Remove(name);
  foreach(var item in new[]{("GIT_CONFIG_NOSYSTEM","1"),("GIT_CONFIG_GLOBAL","/dev/null"),("GIT_TERMINAL_PROMPT","0"),("GIT_OPTIONAL_LOCKS","0"),
   ("GIT_AUTHOR_NAME","Offline fixture"),("GIT_AUTHOR_EMAIL","fixture@invalid"),("GIT_COMMITTER_NAME","Offline fixture"),("GIT_COMMITTER_EMAIL","fixture@invalid"),
   ("GIT_AUTHOR_DATE","2000-01-01T00:00:00Z"),("GIT_COMMITTER_DATE","2000-01-01T00:00:00Z")})start.Environment[item.Item1]=item.Item2;
  foreach(var arg in new[]{"-c","core.hooksPath="+System.IO.Path.Combine(GitRoot,"disabled-hooks"),"-c","commit.gpgSign=false","-c","core.fsmonitor=false","-c","core.untrackedCache=false"}.Concat(args))start.ArgumentList.Add(arg);
  GitChild? child=null;
  if(mutation){
   Check(!epochMode,"epoch direct Git mutation is prohibited");
   child=new(){Invocation=Guid.NewGuid().ToString("N"),Identity=effectIdentity.Value??"",Repository=GitRoot,RepositoryId=Setting("fixtureId"),Args=args,InputDigest=DigestText(input??"")};
   Check(child.Identity!="","Git mutation requires effect identity");AtomicWrite("physical-child/v1",JsonSerializer.Serialize(child));
   Observe(new {operation="physical-child-launch",child.Invocation,child.Identity,command=args[0]});Checkpoint("before-git-child-start");
  }
  using var process=new System.Diagnostics.Process{StartInfo=start};
  // If creation fails, leave the pre-launch fence unresolved rather than
  // asserting that no child exists from an unavailable start observation.
  Check(process.Start(),"Git child creation failed");
  if(child!=null){child.Pid=process.Id;AtomicWrite("physical-child/v1",JsonSerializer.Serialize(child));}
  Observe(new {operation="physical-git-start",command=args[0],mutation,pid=process.Id,invocation=child?.Invocation});
  var stdout=GitOutput(process.StandardOutput);var stderr=GitOutput(process.StandardError);
  async System.Threading.Tasks.Task Feed(){try{if(input!=null)await process.StandardInput.WriteAsync(input);}finally{process.StandardInput.Close();}}
  var feed=Feed();var exited=process.WaitForExitAsync();
  Exception? failure=null;
  try{System.Threading.Tasks.Task.WhenAll(feed,stdout,stderr,exited).WaitAsync(TimeSpan.FromMilliseconds(deadline)).GetAwaiter().GetResult();}
  catch(Exception error){
   failure=error;Observe(new {operation="physical-git-termination",command=args[0],pid=process.Id,reason=error.GetType().Name});
   // Failure to terminate/join/drain keeps the active fence. Never publish
   // quiescence merely because termination was requested or the parent exits.
   if(!process.HasExited)process.Kill(true);
   exited.WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();process.StandardInput.Close();
   try{System.Threading.Tasks.Task.WhenAll(feed,stdout,stderr).WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();}
   catch{if(!feed.IsCompleted||!stdout.IsCompletedSuccessfully||!stderr.IsCompletedSuccessfully)throw new InvalidOperationException("Git join/drain unresolved; explicit disposition required",error);}
  }
  Check(process.HasExited&&feed.IsCompleted&&stdout.IsCompletedSuccessfully&&stderr.IsCompletedSuccessfully,"Git quiescence unavailable");
  string output=stdout.GetAwaiter().GetResult(),errorText=stderr.GetAwaiter().GetResult();
  if(child!=null){child.State="quiescent";child.ExitCode=process.ExitCode;child.InputClosed=true;child.OutputDrained=true;AtomicWrite("physical-child/v1",JsonSerializer.Serialize(child));Observe(new {operation="physical-child-quiescent",child.Invocation,child.Identity,child.Pid,child.ExitCode});}
  Observe(new {operation="physical-git-exit",command=args[0],args,mutation,exitCode=process.ExitCode,childExited=true});
  if(failure!=null)throw new InvalidOperationException("Git command interrupted; physical effect must be inspected",failure);
  Check(process.ExitCode==0,"Git command failed: "+args[0]+": "+errorText);return trim?output.TrimEnd('\r','\n'):output;
 }
 // Git's regular-file mode records the owner's executable bit. Other Unix
 // permission bits, ownership and timestamps are not tree-mode facts.
 string FileFact(string name,string mode,string digest)=>name+":"+(Setting("worktreeModeControl")=="content-only"?"":mode+":")+digest;
 string WorktreeState(){
  var rows=new List<string>();
  void Walk(string dir){foreach(string entry in System.IO.Directory.EnumerateFileSystemEntries(dir).OrderBy(x=>x,StringComparer.Ordinal)){
   string name=System.IO.Path.GetRelativePath(GitRoot,entry);if(name==".git"||name=="disabled-hooks")continue;
   Check((System.IO.File.GetAttributes(entry)&System.IO.FileAttributes.ReparsePoint)==0,"symlinked worktree entry");
   if(System.IO.Directory.Exists(entry))Walk(entry);else{
    string mode=(System.IO.File.GetUnixFileMode(entry)&System.IO.UnixFileMode.UserExecute)!=0?"100755":"100644";
    rows.Add(FileFact(name,mode,Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(entry))).ToLowerInvariant()));
   }
  }}Walk(GitRoot);return string.Join("\n",rows);
 }
 GitState PhysicalState(){
  Check(Git(new[]{"rev-parse","--show-toplevel"})==GitRoot,"repository/worktree path");
  Check(Git(new[]{"rev-parse","--absolute-git-dir"})==System.IO.Path.Combine(GitRoot,".git"),"standalone fixture Git directory");
  return new(){Head=Git(new[]{"rev-parse","HEAD"}),Symbolic=Git(new[]{"symbolic-ref","HEAD"}),
   Refs=Git(new[]{"show-ref"}),Objects=string.Join("\n",Git(new[]{"cat-file","--batch-all-objects","--batch-check=%(objectname) %(objecttype)"}).Split('\n').OrderBy(x=>x,StringComparer.Ordinal)),
   IndexBytes=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(System.IO.Path.Combine(GitRoot,".git","index")))).ToLowerInvariant(),
   IndexEntries=Git(new[]{"ls-files","--stage"}),Worktree=WorktreeState()};
 }
 string PlanKey(string identity)=>"physical-plan/v1/"+identity;
 GitPlan LoadPlan(string identity){
  var plan=JsonSerializer.Deserialize<GitPlan>(System.IO.File.ReadAllText(StoragePath(PlanKey(identity))))!;
  Check(plan.Version=="3"&&plan.Identity==identity&&plan.Repository==GitRoot&&plan.RepositoryId==Setting("fixtureId"),"physical intent ownership/version");
  Check(plan.Before.Symbolic=="refs/heads/main","bounded branch");
  Check(Git(new[]{"rev-parse",plan.Selected+"^{tree}"})==plan.Tree,"selected tree changed");
  Check(Git(new[]{"diff",plan.Before.Head,plan.Selected,"--","file.txt"})==plan.Patch,"selected patch changed");
  using var selectedIntent=JsonDocument.Parse(plan.Intent);Check(selectedIntent.RootElement.GetProperty("commit").GetString()==plan.Selected,"selected intent changed");
  if(plan.NoMutation)Check(selectedIntent.RootElement.GetProperty("integrated").GetString()==plan.Commit&&plan.Before.Head==plan.Commit,"retained no-mutation HEAD");
  else Check(Git(new[]{"hash-object","-t","commit","--stdin"},plan.CommitBytes)==plan.Commit,"predicted commit changed");
  return plan;
 }
 void PhysicalPrepare(string value){
  using var json=JsonDocument.Parse(value);var admission=json.RootElement;
  if(admission.GetProperty("phase").GetString()!="pending")return;
  string identity=admission.GetProperty("token").GetString()!,intent=admission.GetProperty("intent").GetString()!;
  string file=StoragePath(PlanKey(identity));
  if(System.IO.File.Exists(file)){Check(LoadPlan(identity).Intent==intent,"conflicting physical intent");return;}
  using var selectedIntent=JsonDocument.Parse(intent);string selected=selectedIntent.RootElement.GetProperty("commit").GetString()!;
  Check(System.Text.RegularExpressions.Regex.IsMatch(selected,"^[0-9a-f]{40}$"),"bounded SHA1 selected commit");
  var before=PhysicalState();Check(before.Symbolic=="refs/heads/main","bounded primary worktree");
  string tree=Git(new[]{"rev-parse",selected+"^{tree}"}),listing=Git(new[]{"ls-tree","-r",selected});
  Check(System.Text.RegularExpressions.Regex.IsMatch(listing,"^100644 blob [0-9a-f]{40}\\tfile.txt$"),"single plain-text file fixture");
  string blob=listing.Split(' ')[2].Split('\t')[0],expectedIndex="100644 "+blob+" 0\tfile.txt";
  string expectedWorktree=FileFact("file.txt",listing.Split(' ')[0],DigestText(Git(new[]{"show",selected+":file.txt"},trim:false)));
  string baseListing=Git(new[]{"ls-tree","-r",before.Head});
  Check(System.Text.RegularExpressions.Regex.IsMatch(baseListing,"^100644 blob [0-9a-f]{40}\\tfile.txt$"),"bounded initial tree");
  string baseBlob=baseListing.Split(' ')[2].Split('\t')[0];
  Check(before.IndexEntries=="100644 "+baseBlob+" 0\tfile.txt"&&before.Worktree==FileFact("file.txt",baseListing.Split(' ')[0],DigestText(Git(new[]{"show",before.Head+":file.txt"},trim:false))),"clean owned initial index/worktree");
  string integrated=selectedIntent.RootElement.GetProperty("integrated").GetString()!;bool noMutation=integrated!="";
  string patch=Git(new[]{"diff",before.Head,selected,"--","file.txt"});
  if(noMutation)Check(before.Head==integrated&&before.IndexEntries==expectedIndex&&before.Worktree==expectedWorktree&&patch=="","already integrated physical state");
  else Check(patch==Setting("patch"),"selected patch binding");
  string message=identity+"\n",bytes=$"tree {tree}\nparent {before.Head}\nauthor Offline fixture <fixture@invalid> 946684800 +0000\ncommitter Offline fixture <fixture@invalid> 946684800 +0000\n\n{message}";
  string commit=noMutation?integrated:Git(new[]{"hash-object","-t","commit","--stdin"},bytes);
  Check(noMutation||!before.Objects.Split('\n').Any(x=>x.StartsWith(commit+" ",StringComparison.Ordinal)),"preexisting predicted commit");
  var plan=new GitPlan{Identity=identity,Intent=intent,Repository=GitRoot,RepositoryId=Setting("fixtureId"),Selected=selected,Tree=tree,Patch=patch,Commit=commit,CommitBytes=noMutation?"":bytes,NoMutation=noMutation,ExpectedIndex=expectedIndex,ExpectedWorktree=expectedWorktree,Before=before};
  Checkpoint("before-physical-intent");AtomicWrite(PlanKey(identity),JsonSerializer.Serialize(plan));Observe(new {operation="physical-intent",identity,selected,tree,commit,preHead=before.Head});Checkpoint("after-physical-intent");
 }
 void PhysicalPrepareJournal(string value){
  using var json=JsonDocument.Parse(value);var journal=json.RootElement;
  if(journal.GetProperty("state").GetString()!="pending")return;
  PhysicalPrepare(JsonSerializer.Serialize(new {phase="pending",token=journal.GetProperty("effectIdentity").GetString(),intent=journal.GetProperty("intent").GetString()}));
 }
 string Classify(GitPlan plan,GitState current){
  if(JsonSerializer.Serialize(current)==JsonSerializer.Serialize(plan.Before))return plan.NoMutation?"applied":"absent";
  string objects=string.Join("\n",(plan.Before.Objects+"\n"+plan.Commit+" commit").Split('\n').OrderBy(x=>x,StringComparer.Ordinal));
  string refs=plan.Before.Refs.Replace(plan.Before.Head+" refs/heads/main",plan.Commit+" refs/heads/main",StringComparison.Ordinal);
  if(current.Symbolic==plan.Before.Symbolic&&current.Objects==objects&&current.Refs==refs&&current.Head==plan.Commit&&current.IndexEntries==plan.ExpectedIndex&&current.Worktree==plan.ExpectedWorktree)return "applied";
  return "unknown"; // Includes partial/unowned/contradictory physical state.
 }
 string Corroborated(GitPlan plan,GitState current){
  string state=Classify(plan,current);
  foreach(string phase in new[]{"commit","head","save"}){
   string file=StoragePath("physical-receipt/"+plan.Identity+"/"+phase);if(!System.IO.File.Exists(file))continue;
   using var receipt=JsonDocument.Parse(System.IO.File.ReadAllText(file));var row=receipt.RootElement;
   if(state=="absent"||row.GetProperty("phase").GetString()!=phase||row.GetProperty("identity").GetString()!=plan.Identity||row.GetProperty("Commit").GetString()!=plan.Commit)return "unknown";
  }return state;
 }
 NyStr PhysicalEvidence(string identity){
  string state="unknown",head="",reason="inspection unavailable";
  try{if(Setting("evidence")!="unavailable"){
   if(Setting("physicalControl")=="receipt-absence"){
    // Deliberately faulty paired control: the reviewed synthetic absence rule.
    state=System.IO.File.Exists(StoragePath("physical-receipt/"+identity+"/commit"))?"unknown":"absent";reason="receipt-only control";
   }else{var plan=LoadPlan(identity);var current=PhysicalState();state=Corroborated(plan,current);head=state=="applied"?current.Head:"";reason="complete local state comparison";}
  }}catch(Exception error){reason=error.Message;}
  Observe(new {operation="effect-evidence",identity,state,head,reason});return JsonSerializer.Serialize(new {state,head});
 }
 string PhysicalRead(string key,string value){
  if(key!="registry/v1")return value;
  try{
   if(System.IO.File.Exists(StoragePath("physical-continuation-intent/v1")))return ObservationAdmission(value);
   string launch=StoragePath("physical-child/v1");
   if(System.IO.File.Exists(launch))Check(JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(launch))!.State=="quiescent","Git child launch unresolved before admission");
   using var json=JsonDocument.Parse(value);var admission=json.RootElement;
   if(admission.GetProperty("phase").GetString()!="ready")return value;
   string identity=admission.GetProperty("token").GetString()!;
   var plan=LoadPlan(identity);Check(plan.Intent==admission.GetProperty("intent").GetString(),"ready physical intent mismatch");
   using var intent=JsonDocument.Parse(plan.Intent);string target=intent.RootElement.GetProperty("target").GetInt64().ToString();
   string integrated=admission.GetProperty("entries").EnumerateArray().Single(x=>x.GetProperty("id").GetString()==target).GetProperty("integrated").GetString()!;
   string state=Corroborated(plan,PhysicalState());
   Check(state=="applied"&&integrated==plan.Commit||state=="absent"&&integrated==""&&admission.GetProperty("outcome").GetString()!.StartsWith("err:",StringComparison.Ordinal),"ready physical effect/HEAD mismatch");
   return value;
  }catch(Exception error){Observe(new {operation="physical-ready-rejected",reason=error.Message});return "{physical-unresolved}";}
 }
 void PhysicalStep(string phase,string patch){
  string identity=effectIdentity.Value??"";var plan=LoadPlan(identity);Check(!plan.NoMutation,"no-mutation intent cannot dispatch Git");Check(patch==(phase=="save"?plan.Commit:""),"effect argument mismatch");
  if(phase=="commit"){
   Check(Corroborated(plan,PhysicalState())=="absent"||Setting("physicalControl")=="receipt-absence","effect absence required before dispatch");
   string commit=Git(new[]{"commit-tree",plan.Tree,"-p",plan.Before.Head},identity+"\n",mutation:true);Check(commit==plan.Commit,"physical commit identity");Checkpoint("after-git-object");
   Git(new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head},mutation:true);Checkpoint("after-git-ref");
  }else if(phase=="head"){Check(Git(new[]{"rev-parse","HEAD"})==plan.Commit,"HEAD observation mismatch");Observe(new {operation="physical-head-observed",head=plan.Commit});}
  else if(phase=="save"){Git(new[]{"read-tree","--reset","-u",plan.Commit},mutation:true);Checkpoint("after-git-worktree");Check(Classify(plan,PhysicalState())=="applied","physical worktree completion");}
  AtomicWrite("physical-receipt/"+identity+"/"+phase,JsonSerializer.Serialize(new {phase,identity,plan.Commit}));
  Observe(new {operation="effect-persisted",phase,identity,patch});
 }
 string PhysicalHead()=>Git(new[]{"rev-parse","HEAD"});

 // Explicit bounded retain disposition. All original application records and
 // the launch fence remain byte-for-byte intact; this never supplies an outcome.
 sealed class GitJoin {
  public string Version {get;set;}="";public string Invocation {get;set;}="";public string Identity {get;set;}="";
  public string Repository {get;set;}="";public string RepositoryId {get;set;}="";public string LaunchDigest {get;set;}="";
  public string OwnerDigest {get;set;}="";public int OwnerPid {get;set;}public int ChildPid {get;set;}
  public string[] Args {get;set;}=Array.Empty<string>();public string InputDigest {get;set;}="";
  public int? ExitCode {get;set;}public string ExitSignal {get;set;}="";public bool InputClosed {get;set;}public bool OutputDrained {get;set;}
  public string OutputDigest {get;set;}="";public string ErrorDigest {get;set;}="";
 }
 GitJoin LoadJoin(GitChild child,string raw){
  var witness=JsonSerializer.Deserialize<GitJoin>(System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+child.Invocation)))!;
  Check(child.Version=="2"&&child.Pid.HasValue&&child.OwnerDigest!=""&&witness.Version=="1"&&witness.Invocation==child.Invocation&&witness.Identity==child.Identity&&witness.Repository==child.Repository&&witness.RepositoryId==child.RepositoryId&&witness.LaunchDigest==DigestText(raw)&&witness.OwnerDigest==child.OwnerDigest&&witness.OwnerPid==child.Pid&&witness.ChildPid>0&&witness.Args.SequenceEqual(child.Args)&&witness.InputDigest==child.InputDigest&&witness.InputClosed&&witness.OutputDrained&&(witness.ExitCode.HasValue&&witness.ExitSignal==""||!witness.ExitCode.HasValue&&witness.ExitSignal=="SIGKILL"),"controlled child join witness mismatch");
  Check(System.Text.RegularExpressions.Regex.IsMatch(witness.OutputDigest,@"\A[0-9a-f]{64}\z")&&System.Text.RegularExpressions.Regex.IsMatch(witness.ErrorDigest,@"\A[0-9a-f]{64}\z"),"join output capture unavailable");return witness;
 }
 string OwnedGit(string[] args,string? input,bool trim,string launchKey="physical-child/v1"){
  string owner=epochMode?EpochOwnerPath():System.IO.Path.GetFullPath(Setting("gitOwner"));
  Check(System.IO.File.Exists(owner)&&new System.IO.FileInfo(owner).LinkTarget==null,"controlled child owner unavailable");
  var child=new GitChild{Version="2",Invocation=Guid.NewGuid().ToString("N"),Identity=effectIdentity.Value??"",Repository=GitRoot,RepositoryId=Setting("fixtureId"),Args=args,InputDigest=DigestText(input??""),OwnerDigest=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(owner))).ToLowerInvariant()};
  if(epochMode)Check(child.OwnerDigest==SupportedEpochOwner,"epoch launch owner differs from pin");
  Check(child.Identity!="","owned mutation requires identity");
  Check(epochMode&&System.Text.RegularExpressions.Regex.IsMatch(launchKey,@"\Aphysical-epoch-child/v1/[0-9a-f]{64}/[012]\z")&&!System.IO.File.Exists(StoragePath(launchKey))||launchKey=="physical-child/v1"||System.Text.RegularExpressions.Regex.IsMatch(launchKey,@"\Aphysical-continuation-child/v1/[a-zA-Z0-9_-]{1,80}/[01]\z")&&!System.IO.File.Exists(StoragePath(launchKey)),"owned launch slot conflict");
  AtomicWrite(launchKey,JsonSerializer.Serialize(child));
  Observe(new {operation="physical-child-launch",child.Invocation,child.Identity,command=args[0],owner=true});Checkpoint("before-git-child-start");
  var start=new System.Diagnostics.ProcessStartInfo("node"){UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};start.ArgumentList.Add(owner);
  using var process=new System.Diagnostics.Process{StartInfo=start};Check(process.Start(),"controlled owner creation failed");child.Pid=process.Id;
  string raw=JsonSerializer.Serialize(child);AtomicWrite(launchKey,raw);
  int deadline=Setting("gitDeadlineMs")==""?10000:int.Parse(Setting("gitDeadlineMs"));Check(deadline>=250&&deadline<=10000,"bounded owned Git deadline");
  var output=GitOutput(process.StandardOutput);var error=GitOutput(process.StandardError);
  process.StandardInput.Write(JsonSerializer.Serialize(new {storage=StorageRoot,repository=GitRoot,invocation=child.Invocation,launchKey,input=input??"",deadlineMs=deadline}));process.StandardInput.Close();
  Observe(new {operation="physical-git-owner-start",child.Invocation,pid=process.Id,command=args[0]});
  // No kill of the owner on launcher loss: it owns root exit and both drains.
  System.Threading.Tasks.Task.WhenAll(output,error,process.WaitForExitAsync()).WaitAsync(TimeSpan.FromMilliseconds(deadline+4000)).GetAwaiter().GetResult();
  Check(process.ExitCode==0,"controlled owner join unavailable");var witness=LoadJoin(child,raw);
  Check(witness.OutputDigest==DigestText(output.Result)&&witness.ErrorDigest==DigestText(error.Result),"controlled owner capture mismatch");
  Check(witness.ExitCode.HasValue,"owned Git child interrupted; inspect separately");
  child.State="quiescent";child.ExitCode=witness.ExitCode;child.InputClosed=true;child.OutputDrained=true;AtomicWrite(launchKey,JsonSerializer.Serialize(child));
  Observe(new {operation="physical-child-quiescent",child.Invocation,child.Identity,child.Pid,child.ExitCode,owner=true});
  Observe(new {operation="physical-git-exit",command=args[0],args,mutation=true,exitCode=witness.ExitCode,childExited=true});
  Check(witness.ExitCode==0,"Git command failed: "+args[0]+": "+error.GetAwaiter().GetResult());return trim?output.Result.TrimEnd('\r','\n'):output.Result;
 }
 bool dispositionInspection;
 void RunDisposition(){
  try{Console.WriteLine(RetainDisposition(System.IO.File.ReadAllText(Setting("dispositionRequest"))));}
  catch(Exception error){Console.WriteLine("err:unresolved");Observe(new {operation="physical-disposition-rejected",reason=error.Message});}
  Environment.Exit(0);
 }
 string OwnedTail(GitPlan plan,GitState current){
  if(Classify(plan,current)=="applied")return "applied";
  if(JsonSerializer.Serialize(current)==JsonSerializer.Serialize(plan.Before))return "absent";
  string objects=string.Join("\n",(plan.Before.Objects+"\n"+plan.Commit+" commit").Split('\n').OrderBy(x=>x,StringComparer.Ordinal));
  bool rest=current.Symbolic==plan.Before.Symbolic&&current.Objects==objects&&current.IndexBytes==plan.Before.IndexBytes&&current.IndexEntries==plan.Before.IndexEntries&&current.Worktree==plan.Before.Worktree;
  if(rest&&current.Head==plan.Before.Head&&current.Refs==plan.Before.Refs)return "object-only";
  if(rest&&current.Head==plan.Commit&&current.Refs==plan.Before.Refs.Replace(plan.Before.Head+" refs/heads/main",plan.Commit+" refs/heads/main",StringComparison.Ordinal))return "ref-only";
  return "unknown";
 }
 public string RetainDisposition(string request){
  using var document=JsonDocument.Parse(request);var r=document.RootElement;
  string id=r.GetProperty("id").GetString()!,authorization=AuthorityValue(r,"authorization"),invocation=r.GetProperty("invocation").GetString()!,identity=r.GetProperty("identity").GetString()!;
  Check(System.Text.RegularExpressions.Regex.IsMatch(id,@"\A[a-zA-Z0-9_-]{1,80}\z")&&id!=identity&&authorization==ScenarioAuthority("dispositionAuthorization"),"disposition identity/authorization");
  Check(r.GetProperty("action").GetString()=="retain-unresolved"&&r.GetProperty("repository").GetString()==GitRoot&&r.GetProperty("repositoryId").GetString()==Setting("fixtureId")&&r.GetProperty("launchDigest").GetString()!=""&&r.GetProperty("planDigest").GetString()!=""&&r.GetProperty("expectedState").GetString()!="", "disposition payload");
  Check(Setting("worktreeModeControl")==""&&Setting("physicalControl")=="","disposition requires enabled physical evidence");
  string raw=System.IO.File.ReadAllText(StoragePath("physical-child/v1"));var child=JsonSerializer.Deserialize<GitChild>(raw)!;
  string planRaw=System.IO.File.ReadAllText(StoragePath(PlanKey(identity)));
  Check(child.Invocation==invocation&&child.Identity==identity&&r.GetProperty("launchDigest").GetString()==DigestText(raw)&&r.GetProperty("planDigest").GetString()==DigestText(planRaw),"disposition launch/plan correlation");
  string witnessDigest="";
  if(child.State=="active"){
   LoadJoin(child,raw);witnessDigest=DigestText(System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+invocation)));
  }else{Check(child.State=="quiescent","disposition child state");GitChildGuard();}
  Check(child.Repository==GitRoot&&child.RepositoryId==Setting("fixtureId"),"disposition child repository");
  string requestDigest=DigestText(request),key="physical-disposition/v1/"+id,file=StoragePath(key);
  // Only this explicit, read-only scope may inspect an active witnessed launch.
  // Every inspected Git command still validates the original args and plan.
  dispositionInspection=true;
  try{
   Check(Setting("evidence")!="unavailable","disposition inspection unavailable");var plan=LoadPlan(identity);var current=PhysicalState();
   string state=OwnedTail(plan,current);Check(state!="unknown"&&state==r.GetProperty("expectedState").GetString(),"disposition physical state mismatch");
   foreach(string phase in new[]{"commit","head","save"}){
    string receipt=StoragePath("physical-receipt/"+identity+"/"+phase);if(!System.IO.File.Exists(receipt))continue;
    using var proof=JsonDocument.Parse(System.IO.File.ReadAllText(receipt));var row=proof.RootElement;
    bool allowed=phase=="save"?state=="applied"&&child.Args[0]=="read-tree":(state=="ref-only"||state=="applied")&&(child.Args[0]=="update-ref"||child.Args[0]=="read-tree");
    Check(allowed&&row.GetProperty("phase").GetString()==phase&&row.GetProperty("identity").GetString()==identity&&row.GetProperty("Commit").GetString()==plan.Commit,"disposition side receipt mismatch");
   }
   if(child.Args[0]=="commit-tree")Check(state is "absent" or "object-only","disposition command/tail mismatch");
   if(child.Args[0]=="update-ref")Check(state is "object-only" or "ref-only","disposition command/tail mismatch");
   if(child.Args[0]=="read-tree")Check(state is "ref-only" or "applied","disposition command/tail mismatch");
   string result="ok:retained-unresolved:"+state;
   string stateDigest=DigestText(JsonSerializer.Serialize(current));
   if(System.IO.File.Exists(file)){
    using var prior=JsonDocument.Parse(System.IO.File.ReadAllText(file));var p=prior.RootElement;
    Check(p.GetProperty("version").GetString()=="1"&&p.GetProperty("id").GetString()==id&&p.GetProperty("requestDigest").GetString()==requestDigest&&p.GetProperty("invocation").GetString()==invocation&&p.GetProperty("identity").GetString()==identity&&p.GetProperty("launchDigest").GetString()==DigestText(raw)&&p.GetProperty("planDigest").GetString()==DigestText(planRaw)&&p.GetProperty("repository").GetString()==GitRoot&&p.GetProperty("repositoryId").GetString()==Setting("fixtureId")&&p.GetProperty("action").GetString()=="retain-unresolved"&&p.GetProperty("state").GetString()==state&&p.GetProperty("witnessDigest").GetString()==witnessDigest&&p.GetProperty("stateDigest").GetString()==stateDigest&&p.GetProperty("result").GetString()==result&&p.GetProperty("originalOutcome").GetString()=="not-inferred","conflicting retained disposition");return result;
   }
   Checkpoint("before-disposition-publication");
   AtomicWrite(key,JsonSerializer.Serialize(new {version="1",id,requestDigest,invocation,identity,launchDigest=DigestText(raw),planDigest=DigestText(planRaw),repository=GitRoot,repositoryId=Setting("fixtureId"),action="retain-unresolved",state,stateDigest,witnessDigest,result,originalOutcome="not-inferred"}));
   Observe(new {operation="physical-disposition-retained",id,invocation,identity,state,result});Checkpoint("after-disposition-publication");return result;
  }finally{dispositionInspection=false;}
 }

 // Experimental administrative example policy. The semantic graph/core stay
 // generic. This completes a new physical request, never the lost original.
 sealed class ContinuationIntent {
  public string Version {get;set;}="1";public string Id {get;set;}="";public string Request {get;set;}="";public string RequestDigest {get;set;}="";
  public string Identity {get;set;}="";public string Invocation {get;set;}="";public string Repository {get;set;}="";public string RepositoryId {get;set;}="";
  public string PlanDigest {get;set;}="";public string LaunchDigest {get;set;}="";public string DispositionDigest {get;set;}="";public string IntentDigest {get;set;}="";
  public string State {get;set;}="";public string StateDigest {get;set;}="";public string RegistryDigest {get;set;}="";
  public Dictionary<string,string> Originals {get;set;}=new();public string[][] Commands {get;set;}=Array.Empty<string[]>();
 }
 const string ContinuationKey="physical-continuation-intent/v1",AdmissionKey="physical-observation-intent/v1",ReleaseKey="physical-observation-release/v1";
 bool observationAdmission;
 static string Required(JsonElement row,string key)=>row.GetProperty(key).GetString()!;
 string AuthorityValue(JsonElement row,string key,bool allowEmpty=false){
  Check(row.TryGetProperty(key,out var value)&&value.ValueKind==JsonValueKind.String,"authority must be a JSON string: "+key);
  string authority=value.GetString()??throw new InvalidOperationException("null authority: "+key);
  Check(allowEmpty||authority.Length!=0,"empty authority: "+key);return authority;
 }
 string ScenarioAuthority(string key,bool optional=false){
  if(optional&&!scenario.TryGetProperty(key,out _))return "";
  return AuthorityValue(scenario,key,optional);
 }
 void AdministrativeAuthority(JsonElement row,string setting,string action){
  string id=Required(row,"id"),authorization=AuthorityValue(row,"authorization");
  Check(System.Text.RegularExpressions.Regex.IsMatch(id,@"\A[a-zA-Z0-9_-]{1,80}\z")&&authorization==ScenarioAuthority(setting)&&Required(row,"action")==action,"separate request identity/authority/action");
 }
 void RunContinuation(){
  try{
   Check(Setting("dispositionRequest")==""&&(Setting("continuationRequest")=="")!=(Setting("releaseRequest")==""),"one administrative request required");
   Console.WriteLine(Setting("continuationRequest")!=""?ContinueTail(System.IO.File.ReadAllText(Setting("continuationRequest"))):ReleaseObservation(System.IO.File.ReadAllText(Setting("releaseRequest"))));
  }catch(Exception error){Console.WriteLine("err:unresolved");Observe(new {operation="physical-continuation-rejected",reason=error.Message});}
  Environment.Exit(0);
 }
 string NewLaunchKey(string id,int index)=>"physical-continuation-child/v1/"+id+"/"+index;
 string ContinuationResultKey(string id)=>"physical-continuation-result/v1/"+id;
 Dictionary<string,string> OriginalInventory()=>System.IO.Directory.GetFiles(StorageRoot).OrderBy(x=>x,StringComparer.Ordinal).ToDictionary(x=>System.IO.Path.GetFileName(x)!,x=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(x))).ToLowerInvariant());
 void OriginalLineage(ContinuationIntent intent,bool interruptedDisposition=false){
  Check(intent.Originals.Count>0,"missing original lineage");
  foreach(var item in intent.Originals){
   Check(System.Text.RegularExpressions.Regex.IsMatch(item.Key,@"\A[0-9a-f]{64}\.json\z"),"invalid lineage filename");
   Check(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(System.IO.Path.Combine(StorageRoot,item.Key)))).ToLowerInvariant()==item.Value,"original evidence changed");
  }
  var allowed=intent.Originals.Keys.ToHashSet(StringComparer.Ordinal);
  if(interruptedDisposition)allowed.Add(System.IO.Path.GetFileName(StoragePath(InterruptedDispositionKey)));
  foreach(string key in new[]{ContinuationKey,ContinuationResultKey(intent.Id),AdmissionKey,ReleaseKey})allowed.Add(System.IO.Path.GetFileName(StoragePath(key)));
  for(int i=0;i<intent.Commands.Length;i++){
   string key=NewLaunchKey(intent.Id,i);allowed.Add(System.IO.Path.GetFileName(StoragePath(key)));
   if(System.IO.File.Exists(StoragePath(key))){var owned=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath(key)))!;allowed.Add(System.IO.Path.GetFileName(StoragePath("physical-join/v1/"+owned.Invocation)));}
  }
  if(System.IO.File.Exists(StoragePath(AdmissionKey))){using var decision=JsonDocument.Parse(System.IO.File.ReadAllText(StoragePath(AdmissionKey)));string releaseId=Required(decision.RootElement,"id");Check(System.Text.RegularExpressions.Regex.IsMatch(releaseId,@"\A[a-zA-Z0-9_-]{1,80}\z"),"invalid release lineage");allowed.Add(System.IO.Path.GetFileName(StoragePath("physical-observation-result/v1/"+releaseId)));}
  Check(System.IO.Directory.GetFiles(StorageRoot).All(x=>allowed.Contains(System.IO.Path.GetFileName(x))),"unbound storage evidence appeared");
  Check(Setting("evidence")!="unavailable"&&Setting("physicalControl")==""&&Setting("worktreeModeControl")=="","enabled inspection required");
  Check(intent.Version=="1"&&intent.Repository==GitRoot&&intent.RepositoryId==Setting("fixtureId"),"continuation domain mismatch");
  string launch=System.IO.File.ReadAllText(StoragePath("physical-child/v1"));var child=JsonSerializer.Deserialize<GitChild>(launch)!;
  Check(child.Invocation==intent.Invocation&&child.Identity==intent.Identity&&DigestText(launch)==intent.LaunchDigest,"original launch changed");
  if(child.State=="active")LoadJoin(child,launch);else GitChildGuard();
  string planRaw=System.IO.File.ReadAllText(StoragePath(PlanKey(intent.Identity)));var plan=LoadPlan(intent.Identity);
  Check(DigestText(planRaw)==intent.PlanDigest&&DigestText(plan.Intent)==intent.IntentDigest&&!plan.NoMutation,"original plan changed");
  using var request=JsonDocument.Parse(intent.Request);var r=request.RootElement;
  using var retentionRequest=JsonDocument.Parse(Required(r,"retentionRequest"));var q=retentionRequest.RootElement;
  Check(AuthorityValue(r,"authorization")!=AuthorityValue(q,"authorization"),"accepted continuation/retention authority separation");
  Check(intent.Id==Required(r,"id")&&intent.RequestDigest==DigestText(intent.Request)&&intent.State==Required(r,"expectedState")&&intent.StateDigest==Required(r,"observedStateDigest")&&intent.DispositionDigest==Required(r,"dispositionDigest"),"continuation intent/request mismatch");
  string disposition=System.IO.File.ReadAllText(StoragePath("physical-disposition/v1/"+Required(q,"id")));
  Check(DigestText(disposition)==intent.DispositionDigest,"prior disposition changed");
  using var proof=JsonDocument.Parse(disposition);var p=proof.RootElement;
  Check(Required(p,"requestDigest")==DigestText(Required(r,"retentionRequest"))&&Required(p,"identity")==intent.Identity&&Required(p,"invocation")==intent.Invocation&&Required(p,"launchDigest")==intent.LaunchDigest&&Required(p,"planDigest")==intent.PlanDigest&&Required(p,"state")==intent.State&&Required(p,"stateDigest")==intent.StateDigest&&Required(p,"originalOutcome")=="not-inferred","prior disposition lineage mismatch");
  Check(DigestText(System.IO.File.ReadAllText(StoragePath("registry/v1")))==intent.RegistryDigest,"original admission changed");
  string[][] commands=intent.State=="object-only"?new[]{new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head},new[]{"read-tree","--reset","-u",plan.Commit}}:new[]{new[]{"read-tree","--reset","-u",plan.Commit}};
  Check((intent.State is "object-only" or "ref-only")&&JsonSerializer.Serialize(intent.Commands)==JsonSerializer.Serialize(commands),"continuation commands mismatch");
 }
 string CompletionRecord(ContinuationIntent intent,string pending){
  OriginalLineage(intent);var plan=LoadPlan(intent.Identity);var current=PhysicalState();
  Check(OwnedTail(plan,current)=="applied","continuation completion state mismatch");
  var launches=new List<object>();
  for(int i=0;i<intent.Commands.Length;i++){
   string raw=System.IO.File.ReadAllText(StoragePath(NewLaunchKey(intent.Id,i)));var child=JsonSerializer.Deserialize<GitChild>(raw)!;
   Check(child.Version=="2"&&child.State=="quiescent"&&child.Identity==intent.Identity&&child.Repository==GitRoot&&child.RepositoryId==intent.RepositoryId&&child.Args.SequenceEqual(intent.Commands[i])&&child.InputDigest==DigestText("")&&child.Pid.HasValue&&child.ExitCode==0&&child.InputClosed&&child.OutputDrained,"new continuation custody mismatch");
   // The owner witnessed the active launch; reconstruct exactly that payload,
   // retaining both the active digest and final launch bytes in the new result.
   child.State="active";child.ExitCode=null;child.InputClosed=false;child.OutputDrained=false;
   LoadJoin(child,JsonSerializer.Serialize(child));
   launches.Add(new {key=NewLaunchKey(intent.Id,i),invocation=child.Invocation,launchDigest=DigestText(raw),witnessDigest=DigestText(System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+child.Invocation)))});
  }
  return JsonSerializer.Serialize(new {version="1",id=intent.Id,requestDigest=intent.RequestDigest,pendingDigest=DigestText(pending),identity=intent.Identity,invocation=intent.Invocation,dispositionDigest=intent.DispositionDigest,planDigest=intent.PlanDigest,launchDigest=intent.LaunchDigest,intentDigest=intent.IntentDigest,registryDigest=intent.RegistryDigest,repository=GitRoot,repositoryId=intent.RepositoryId,state="applied",stateDigest=DigestText(JsonSerializer.Serialize(current)),launches,result="ok:continued-owned-tail:"+plan.Commit,originalOutcome="not-inferred"});
 }
 string ContinueTail(string request){
  using var document=JsonDocument.Parse(request);var r=document.RootElement;AdministrativeAuthority(r,"continuationAuthorization","continue-owned-tail");
  Check(AuthorityValue(r,"authorization")!=ScenarioAuthority("dispositionAuthorization",true)&&Setting("gitOwner")!="","separate continuation authority and owner required");
  dispositionInspection=true;
  try{
   string file=StoragePath(ContinuationKey),id=Required(r,"id");
   if(System.IO.File.Exists(file)){
    string pending=System.IO.File.ReadAllText(file);var retained=JsonSerializer.Deserialize<ContinuationIntent>(pending)!;
    Check(retained.Id==id&&retained.Request==request&&retained.RequestDigest==DigestText(request),"conflicting continuation decision");OriginalLineage(retained);
    string resultFile=StoragePath(ContinuationResultKey(id));Check(System.IO.File.Exists(resultFile),"pending continuation outcome unknown; no automatic retry");
    string result=CompletionRecord(retained,pending);Check(System.IO.File.ReadAllText(resultFile)==result,"conflicting continuation result");using var resultJson=JsonDocument.Parse(result);return Required(resultJson.RootElement,"result");
   }
   string retentionRaw=Required(r,"retentionRequest");using var qdoc=JsonDocument.Parse(retentionRaw);var q=qdoc.RootElement;
   Check(!System.IO.File.Exists(StoragePath(ContinuationResultKey(id)))&&!System.IO.File.Exists(StoragePath(NewLaunchKey(id,0)))&&!System.IO.File.Exists(StoragePath(NewLaunchKey(id,1)))&&!System.IO.File.Exists(StoragePath(AdmissionKey))&&!System.IO.File.Exists(StoragePath(ReleaseKey)),"orphan or conflicting continuation records");
   string disposition=System.IO.File.ReadAllText(StoragePath("physical-disposition/v1/"+Required(q,"id")));
   Check(id!=Required(q,"id")&&Required(r,"dispositionDigest")==DigestText(disposition),"separate decision/prior disposition binding");
   Check(RetainDisposition(retentionRaw)=="ok:retained-unresolved:"+Required(r,"expectedState"),"prior retention no longer matches");
   dispositionInspection=true;
   using var prior=JsonDocument.Parse(disposition);var p=prior.RootElement;
   string identity=Required(q,"identity");var plan=LoadPlan(identity);var current=PhysicalState();string state=OwnedTail(plan,current);
   Check((state is "object-only" or "ref-only")&&state==Required(r,"expectedState")&&DigestText(JsonSerializer.Serialize(current))==Required(r,"observedStateDigest")&&Required(p,"stateDigest")==Required(r,"observedStateDigest"),"explicit observed continuation state mismatch");
   string registry=System.IO.File.ReadAllText(StoragePath("registry/v1"));using var registryJson=JsonDocument.Parse(registry);var admission=registryJson.RootElement;
   Check(Required(admission,"phase")=="pending"&&Required(admission,"token")==identity&&Required(admission,"intent")==plan.Intent&&Required(admission,"outcome")==""&&Required(admission,"outcomeSource")=="","bounded unresolved original admission required");
   using var journalJson=JsonDocument.Parse(System.IO.File.ReadAllText(StoragePath(Required(admission,"id"))));var journal=journalJson.RootElement;
   Check(Required(journal,"version")=="1"&&Required(journal,"id")==Required(admission,"id")&&Required(journal,"fingerprint")==Required(admission,"fingerprint")&&Required(journal,"intent")==plan.Intent&&Required(journal,"effectIdentity")==identity&&Required(journal,"state")=="pending"&&Required(journal,"outcomeSource")==""&&Required(journal,"outcome")==""&&!System.IO.File.Exists(StoragePath("outcome/"+identity))&&!System.IO.File.Exists(StoragePath("outcome-receipt/"+identity)),"original pending outcome/correlation contradiction");
   var intent=new ContinuationIntent{Id=id,Request=request,RequestDigest=DigestText(request),Identity=identity,Invocation=Required(q,"invocation"),Repository=GitRoot,RepositoryId=Setting("fixtureId"),PlanDigest=Required(q,"planDigest"),LaunchDigest=Required(q,"launchDigest"),DispositionDigest=DigestText(disposition),IntentDigest=DigestText(plan.Intent),State=state,StateDigest=DigestText(JsonSerializer.Serialize(current)),RegistryDigest=DigestText(registry),Originals=OriginalInventory(),Commands=state=="object-only"?new[]{new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head},new[]{"read-tree","--reset","-u",plan.Commit}}:new[]{new[]{"read-tree","--reset","-u",plan.Commit}}};
   OriginalLineage(intent);Checkpoint("before-continuation-intent");string pendingRaw=JsonSerializer.Serialize(intent);AtomicWrite(ContinuationKey,pendingRaw);Checkpoint("after-continuation-intent");
   effectIdentity.Value=identity;
   for(int i=0;i<intent.Commands.Length;i++){
    OriginalLineage(intent);Check(OwnedTail(plan,PhysicalState())==(state=="object-only"&&i==0?"object-only":"ref-only"),"continuation mutation pre-state changed");
    Checkpoint("before-continuation-mutation-"+i);GitGuard();OwnedGit(intent.Commands[i],null,true,NewLaunchKey(id,i));Checkpoint("after-continuation-mutation-"+i);
   }
   string actual=CompletionRecord(intent,pendingRaw);Checkpoint("before-continuation-result");AtomicWrite(ContinuationResultKey(id),actual);Checkpoint("after-continuation-result");using var actualJson=JsonDocument.Parse(actual);return Required(actualJson.RootElement,"result");
  }finally{dispositionInspection=false;}
 }
 string ValidCompletion(string id){
  string pending=System.IO.File.ReadAllText(StoragePath(ContinuationKey));var intent=JsonSerializer.Deserialize<ContinuationIntent>(pending)!;Check(intent.Id==id,"release continuation identity mismatch");
  string actual=System.IO.File.ReadAllText(StoragePath(ContinuationResultKey(id)));Check(actual==CompletionRecord(intent,pending),"release requires actual new continuation outcome");return actual;
 }
 void ReleaseAuthorityLineage(JsonElement release,ContinuationIntent intent){
  using var accepted=JsonDocument.Parse(intent.Request);var continuation=accepted.RootElement;
  using var prior=JsonDocument.Parse(Required(continuation,"retentionRequest"));var retention=prior.RootElement;
  string authority=AuthorityValue(release,"authorization"),continued=AuthorityValue(continuation,"authorization"),retained=AuthorityValue(retention,"authorization");
  // Completion validation authenticates these exact accepted request bytes.
  // Optional current configuration can confirm them, never relabel their authority.
  Check(continued!=retained&&authority!=continued&&authority!=retained,"release authority must differ from accepted continuation and retention");
  string currentContinuation=ScenarioAuthority("continuationAuthorization",true),currentRetention=ScenarioAuthority("dispositionAuthorization",true);
  Check((currentContinuation==""||currentContinuation==continued)&&(currentRetention==""||currentRetention==retained),"current authority configuration contradicts accepted lineage");
 }
 string ReleaseObservation(string request){
  using var document=JsonDocument.Parse(request);var r=document.RootElement;AdministrativeAuthority(r,"releaseAuthorization","release-observation-admission");
  Check(Required(r,"id")!=Required(r,"continuationId"),"separate release decision required");
  dispositionInspection=true;
  try{
   string completion=ValidCompletion(Required(r,"continuationId"));using var cdoc=JsonDocument.Parse(completion);var c=cdoc.RootElement;
   var intent=JsonSerializer.Deserialize<ContinuationIntent>(System.IO.File.ReadAllText(StoragePath(ContinuationKey)))!;ReleaseAuthorityLineage(r,intent);using var originalRequest=JsonDocument.Parse(intent.Request);using var retentionRequest=JsonDocument.Parse(Required(originalRequest.RootElement,"retentionRequest"));Check(Required(r,"id")!=Required(retentionRequest.RootElement,"id"),"release identity must differ from retention");
   Check(Required(r,"continuationDigest")==DigestText(completion)&&Required(r,"observedStateDigest")==Required(c,"stateDigest")&&Required(r,"registryDigest")==Required(c,"registryDigest"),"release decision/state binding");
   string admission=JsonSerializer.Serialize(new {version="1",id=Required(r,"id"),request,requestDigest=DigestText(request),continuationId=Required(r,"continuationId"),continuationDigest=DigestText(completion),stateDigest=Required(c,"stateDigest"),registryDigest=Required(c,"registryDigest"),scope="observation-only",originalOutcome="not-inferred"});
   string pendingFile=StoragePath(AdmissionKey);if(System.IO.File.Exists(pendingFile))Check(System.IO.File.ReadAllText(pendingFile)==admission,"conflicting release intent");
   else{Checkpoint("before-release-intent");AtomicWrite(AdmissionKey,admission);Checkpoint("after-release-intent");}
   string resultKey="physical-observation-result/v1/"+Required(r,"id"),result=JsonSerializer.Serialize(new {version="1",intentDigest=DigestText(admission),result="ok:released-observation-admission",originalOutcome="not-inferred"});
   if(System.IO.File.Exists(StoragePath(resultKey)))Check(System.IO.File.ReadAllText(StoragePath(resultKey))==result,"conflicting release result");
   else{Checkpoint("before-release-result");AtomicWrite(resultKey,result);Checkpoint("after-release-result");}
   string pointer=JsonSerializer.Serialize(new {version="1",id=Required(r,"id"),intentDigest=DigestText(admission),resultDigest=DigestText(result)});
   if(System.IO.File.Exists(StoragePath(ReleaseKey)))Check(System.IO.File.ReadAllText(StoragePath(ReleaseKey))==pointer,"conflicting release activation");
   else{Checkpoint("before-release-activation");AtomicWrite(ReleaseKey,pointer);Checkpoint("after-release-activation");}
   return "ok:released-observation-admission";
  }finally{dispositionInspection=false;}
 }
 string ObservationAdmission(string registry){
  Check(Setting("evidence")!="unavailable","release inspection unavailable");
  using var pointer=JsonDocument.Parse(System.IO.File.ReadAllText(StoragePath(ReleaseKey)));var p=pointer.RootElement;
  string admission=System.IO.File.ReadAllText(StoragePath(AdmissionKey));using var document=JsonDocument.Parse(admission);var r=document.RootElement;
  string result=System.IO.File.ReadAllText(StoragePath("physical-observation-result/v1/"+Required(r,"id")));
  Check(Required(p,"version")=="1"&&Required(r,"version")=="1"&&Required(p,"id")==Required(r,"id")&&Required(p,"intentDigest")==DigestText(admission)&&Required(p,"resultDigest")==DigestText(result)&&Required(r,"scope")=="observation-only"&&Required(r,"originalOutcome")=="not-inferred","release activation mismatch");
  Check(result==JsonSerializer.Serialize(new {version="1",intentDigest=DigestText(admission),result="ok:released-observation-admission",originalOutcome="not-inferred"}),"release actual result mismatch");
  string request=Required(r,"request");using var requestJson=JsonDocument.Parse(request);var q=requestJson.RootElement;
  AuthorityValue(q,"authorization");
  Check(Required(r,"requestDigest")==DigestText(request)&&Required(q,"id")==Required(r,"id")&&Required(q,"action")=="release-observation-admission"&&Required(q,"continuationId")==Required(r,"continuationId")&&Required(q,"continuationDigest")==Required(r,"continuationDigest")&&Required(q,"observedStateDigest")==Required(r,"stateDigest")&&Required(q,"registryDigest")==Required(r,"registryDigest"),"release request lineage mismatch");
  dispositionInspection=true;
  try{string completion=ValidCompletion(Required(r,"continuationId"));using var cdoc=JsonDocument.Parse(completion);var c=cdoc.RootElement;
   ReleaseAuthorityLineage(q,JsonSerializer.Deserialize<ContinuationIntent>(System.IO.File.ReadAllText(StoragePath(ContinuationKey)))!);
   Check(DigestText(completion)==Required(r,"continuationDigest")&&Required(c,"stateDigest")==Required(r,"stateDigest")&&DigestText(registry)==Required(r,"registryDigest")&&Required(c,"registryDigest")==Required(r,"registryDigest"),"released admission facts changed");
  }finally{dispositionInspection=false;}
  observationAdmission=true;Observe(new {operation="physical-observation-admission",id=Required(r,"id"),scope="observation-only",originalOutcome="not-inferred"});return registry;
 }

 // Separate administrative decision for a new request whose actual result is
 // missing. Custody and effects never become an application request outcome.
 const string InterruptedDispositionKey="physical-continuation-disposition/v1";
 const string InterruptedStorageContract="intact-flushed-single-writer-before-slot/v1";
 const string SupportedContinuationOwner="5b9bbf5cdf98cc26296df269815d3c5270e8288ec6a56609abb7f4d595045291";
 void RunInterruptedDisposition(){
  try{
   Check(Setting("dispositionRequest")==""&&Setting("continuationRequest")==""&&Setting("releaseRequest")=="","one administrative request required");
   Console.WriteLine(RetainInterruptedContinuation(System.IO.File.ReadAllText(Setting("interruptedContinuationRequest"))));
  }catch(Exception error){Console.WriteLine("err:unresolved");Observe(new {operation="physical-interrupted-continuation-rejected",reason=error.Message});}
  Environment.Exit(0);
 }
 static bool AdministrativeId(string id)=>System.Text.RegularExpressions.Regex.IsMatch(id,@"\A[a-zA-Z0-9_-]{1,80}\z");
 void InterruptedAuthorityLineage(JsonElement r,ContinuationIntent intent){
  using var accepted=JsonDocument.Parse(intent.Request);var c=accepted.RootElement;
  using var prior=JsonDocument.Parse(Required(c,"retentionRequest"));var q=prior.RootElement;
  Check(AdministrativeId(intent.Id)&&AdministrativeId(Required(q,"id"))&&intent.Id!=Required(q,"id")&&Required(c,"id")==intent.Id&&Required(c,"action")=="continue-owned-tail"&&Required(q,"action")=="retain-unresolved","accepted decision identities/actions");
  Check(Required(r,"id")!=intent.Id&&Required(r,"id")!=Required(q,"id")&&Required(r,"id")!=intent.Identity,"distinct interruption decision identity");
  // Shared accepted-authority guard permits optional absent/empty earlier
  // settings; present values confirm the accepted bytes, never relabel them.
  ReleaseAuthorityLineage(r,intent);
 }
 List<object> InterruptedCustody(ContinuationIntent intent,out GitChild? last){
  var rows=new List<object>();last=null;bool absent=false;
  var plan=JsonSerializer.Deserialize<GitPlan>(System.IO.File.ReadAllText(StoragePath(PlanKey(intent.Identity))))!;
  Check(plan.Version=="3"&&plan.Identity==intent.Identity&&plan.Repository==GitRoot&&plan.RepositoryId==intent.RepositoryId,"interrupted plan ownership");
  string[][] commands=intent.State=="object-only"?new[]{new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head},new[]{"read-tree","--reset","-u",plan.Commit}}:new[]{new[]{"read-tree","--reset","-u",plan.Commit}};
  Check((intent.State is "object-only" or "ref-only")&&JsonSerializer.Serialize(intent.Commands)==JsonSerializer.Serialize(commands),"interrupted command plan mismatch");
  var invocations=new HashSet<string>(StringComparer.Ordinal){intent.Invocation};
  for(int stage=0;stage<intent.Commands.Length;stage++){
   string key=NewLaunchKey(intent.Id,stage),file=StoragePath(key);
   if(!System.IO.File.Exists(file)){
    absent=true;rows.Add(new {key,stage,status="absent",invocation="",launchDigest="",witnessDigest=""});continue;
   }
   Check(!absent&&(last==null||last.State=="quiescent"&&last.ExitCode==0),"new launch sequence contradicts prior custody");
   string raw=System.IO.File.ReadAllText(file);var child=JsonSerializer.Deserialize<GitChild>(raw)!;
   Check(child.Version=="2"&&child.OwnerDigest==SupportedContinuationOwner&&child.Identity==intent.Identity&&child.Repository==GitRoot&&child.RepositoryId==intent.RepositoryId&&child.Args.SequenceEqual(intent.Commands[stage])&&child.InputDigest==DigestText("")&&child.Pid.HasValue&&child.Invocation!=""&&invocations.Add(child.Invocation),"unsupported or contradictory new launch");
   GitJoin witness;
   if(child.State=="active"){
    Check(!child.ExitCode.HasValue&&!child.InputClosed&&!child.OutputDrained,"active new launch flags contradict custody");
    witness=LoadJoin(child,raw);
   }else{
    Check(child.State=="quiescent"&&child.ExitCode.HasValue&&child.InputClosed&&child.OutputDrained,"new launch is not terminal");
    var active=JsonSerializer.Deserialize<GitChild>(raw)!;active.State="active";active.ExitCode=null;active.InputClosed=false;active.OutputDrained=false;
    witness=LoadJoin(active,JsonSerializer.Serialize(active));
    Check(witness.ExitCode==child.ExitCode&&witness.ExitSignal=="","quiescent new launch/owner exit mismatch");
   }
   // These bounded update-ref/read-tree fixtures are silent. A different
   // capture, even a well-formed digest, lacks this fixture's custody contract.
   Check(witness.OutputDigest==DigestText("")&&witness.ErrorDigest==DigestText(""),"unsupported new command capture");
   rows.Add(new {key,stage,status=child.State,invocation=child.Invocation,launchDigest=DigestText(raw),witnessDigest=DigestText(System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+child.Invocation)))});last=child;
  }
  return rows;
 }
 string RetainInterruptedContinuation(string request){
  using var document=JsonDocument.Parse(request);var r=document.RootElement;
  AdministrativeAuthority(r,"interruptedContinuationAuthorization","retain-unresolved-continuation");
  Check(Required(r,"storageContract")==InterruptedStorageContract&&Setting("interruptedContinuationStorageContract")==InterruptedStorageContract,"explicit intact-storage/before-slot contract required");
  string pending=System.IO.File.ReadAllText(StoragePath(ContinuationKey));var intent=JsonSerializer.Deserialize<ContinuationIntent>(pending)!;
  InterruptedAuthorityLineage(r,intent);
  Check(Required(r,"continuationId")==intent.Id&&Required(r,"continuationRequest")==intent.Request&&Required(r,"continuationIntentDigest")==DigestText(pending),"exact accepted continuation binding required");
  Check(!System.IO.File.Exists(StoragePath(ContinuationResultKey(intent.Id)))&&!System.IO.File.Exists(StoragePath(AdmissionKey))&&!System.IO.File.Exists(StoragePath(ReleaseKey)),"actual completion or admission already present");
  // Establish every retained new child's terminal custody before any Git
  // inspection. A missing slot uses only the explicit intact-storage contract.
  // A retained prelaunch/no-PID slot, root exit or PID absence cannot join it.
  var custody=InterruptedCustody(intent,out var last);
  string custodyDigest=DigestText(JsonSerializer.Serialize(custody));Check(Required(r,"custodyDigest")==custodyDigest,"current stage custody differs from decision");
  string originalLaunch=System.IO.File.ReadAllText(StoragePath("physical-child/v1"));var original=JsonSerializer.Deserialize<GitChild>(originalLaunch)!;
  if(original.Version=="2")Check(original.OwnerDigest==SupportedContinuationOwner,"unsupported original owner");
  dispositionInspection=true;
  try{
   OriginalLineage(intent,true);var plan=LoadPlan(intent.Identity);var current=PhysicalState();string state=OwnedTail(plan,current);
   string before=last==null?intent.State:last.Args[0]=="update-ref"?"object-only":"ref-only",after=last==null?intent.State:last.Args[0]=="update-ref"?"ref-only":"applied";
   Check((state==before||state==after)&&(last==null||last.State!="quiescent"||last.ExitCode!=0||state==after),"physical state contradicts staged custody");
   string stateDigest=DigestText(JsonSerializer.Serialize(current));
   Check(state==Required(r,"expectedState")&&stateDigest==Required(r,"observedStateDigest"),"explicit current owned state mismatch");
   var evidence=OriginalInventory();evidence.Remove(System.IO.Path.GetFileName(StoragePath(InterruptedDispositionKey)));
   string evidenceDigest=DigestText(JsonSerializer.Serialize(evidence));Check(Required(r,"evidenceDigest")==evidenceDigest,"exact retained evidence differs from decision");
   string result="ok:retained-unresolved-continuation:"+state;
   string receipt=JsonSerializer.Serialize(new {version="1",id=Required(r,"id"),request,requestDigest=DigestText(request),continuationId=intent.Id,continuationRequestDigest=intent.RequestDigest,pendingDigest=DigestText(pending),identity=intent.Identity,invocation=intent.Invocation,repository=GitRoot,repositoryId=intent.RepositoryId,dispositionDigest=intent.DispositionDigest,planDigest=intent.PlanDigest,launchDigest=intent.LaunchDigest,intentDigest=intent.IntentDigest,registryDigest=intent.RegistryDigest,custody,custodyDigest,evidence,evidenceDigest,state,stateDigest,storageContract=InterruptedStorageContract,result,originalOutcome="not-inferred",continuationOutcome="not-inferred",admission="closed"});
   string file=StoragePath(InterruptedDispositionKey);
   if(System.IO.File.Exists(file)){Check(System.IO.File.ReadAllText(file)==receipt,"conflicting interrupted disposition");return result;}
   Checkpoint("before-interrupted-disposition-publication");AtomicWrite(InterruptedDispositionKey,receipt);
   Observe(new {operation="physical-interrupted-continuation-retained",id=Required(r,"id"),continuationId=intent.Id,state,result});Checkpoint("after-interrupted-disposition-publication");return result;
  }finally{dispositionInspection=false;}
 }

 // Mechanical inspection and ownership for the separate epoch namespace.
 // Request acceptance, authority separation, publication and blocked IDs are
 // authored in the graph. This fixture never produces an old request outcome.
 bool epochMode;
 public NyStr FixtureRead(NyStr key){
  string name=key.ToString();
  if(name=="epochRequest"||name=="epochDispositionRequest"||name=="additionalRequest")return Setting(name)==""?"":System.IO.File.ReadAllText(Setting(name));
  if(!scenario.TryGetProperty(name,out var value))return "";
  // Required opaque input strings retain their JSON type; null and non-string
  // facts cannot impersonate empty/omitted or an accepted string.
  return value.GetRawText();
 }
 string EpochLaunchKey(string[] args)=>"physical-epoch-child/v1/"+DigestText(effectIdentity.Value??"")+"/"+(args[0]=="commit-tree"?0:args[0]=="update-ref"?1:2);
 const string SupportedEpochOwner="987a7bd8f60f4135adc39d2c85f09d7a6673e110d8e3784077d225b7c9015996";
 const long SupportedEpochOwnerLength=4835;
 string EpochOwnerPath(){
  Check(scenario.TryGetProperty("gitOwner",out var supplied)&&supplied.ValueKind==JsonValueKind.String&&!string.IsNullOrEmpty(supplied.GetString()),"epoch requires a nonempty JSON-string owner");
  string owner=System.IO.Path.GetFullPath(supplied.GetString()!);var file=new System.IO.FileInfo(owner);
  Check(file.Exists&&file.LinkTarget==null&&file.Length==SupportedEpochOwnerLength,"epoch owner file unavailable or unsupported");
  for(var directory=file.Directory;directory!=null;directory=directory.Parent)Check(directory.LinkTarget==null,"symlinked epoch owner directory");
  Check(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.IO.File.ReadAllBytes(owner))).ToLowerInvariant()==SupportedEpochOwner,"epoch owner digest is not pinned");
  return owner;
 }
 void EpochChildGuard()=>EpochChildGuardFor("epoch/v1/intent","physical-epoch-child/v1/");
 void EpochChildGuardFor(string intentKey,string childPrefix){
  string file=StoragePath(intentKey);if(!System.IO.File.Exists(file))return;
  using var document=JsonDocument.Parse(System.IO.File.ReadAllText(file));var q=document.RootElement;
  string token="journal:"+Required(q,"integrationIdentity")+":"+DigestText(Required(q,"integrationRequest"));
  bool gap=false;
  for(int stage=0;stage<3;stage++){
   string key=childPrefix+DigestText(token)+"/"+stage;
   if(!System.IO.File.Exists(StoragePath(key))){gap=true;continue;}
   Check(!gap,"epoch child sequence");string raw=System.IO.File.ReadAllText(StoragePath(key));var child=JsonSerializer.Deserialize<GitChild>(raw)!;
   Check(child.Version=="2"&&child.OwnerDigest==SupportedEpochOwner&&child.State=="quiescent"&&child.Pid.HasValue&&child.ExitCode==0&&child.InputClosed&&child.OutputDrained&&child.Identity==token&&child.Repository==GitRoot&&child.RepositoryId==Setting("fixtureId"),"epoch launch remains unresolved");
   var plan=JsonSerializer.Deserialize<GitPlan>(System.IO.File.ReadAllText(StoragePath(PlanKey(token))))!;
   string[] expected=stage==0?new[]{"commit-tree",plan.Tree,"-p",plan.Before.Head}:stage==1?new[]{"update-ref","refs/heads/main",plan.Commit,plan.Before.Head}:new[]{"read-tree","--reset","-u",plan.Commit};
   Check(child.Args.SequenceEqual(expected)&&child.InputDigest==DigestText(stage==0?token+"\n":""),"epoch child plan correlation");
   var active=JsonSerializer.Deserialize<GitChild>(raw)!;active.State="active";active.ExitCode=null;active.InputClosed=false;active.OutputDrained=false;
   var witness=LoadJoin(active,JsonSerializer.Serialize(active));
   Check(witness.ExitCode==0&&witness.ExitSignal==""&&witness.OutputDigest==DigestText(stage==0?plan.Commit+"\n":"")&&witness.ErrorDigest==DigestText(""),"epoch terminal custody mismatch");
  }
 }
 public NyStr PhysicalFacts(){
  try{return EpochFacts();}catch(Exception error){Observe(new {operation="epoch-inspection-rejected",reason=error.Message});return "{unavailable}";}
 }
 string EpochFacts(){
  Check(epochMode&&Setting("evidence")!="unavailable"&&Setting("physicalControl")==""&&Setting("worktreeModeControl")=="","enabled epoch inspection required");
  EpochOwnerPath();
  string receiptRaw=System.IO.File.ReadAllText(StoragePath(InterruptedDispositionKey));using var proof=JsonDocument.Parse(receiptRaw);var r=proof.RootElement;
  string pending=System.IO.File.ReadAllText(StoragePath(ContinuationKey));var continuation=JsonSerializer.Deserialize<ContinuationIntent>(pending)!;
  using var continuationRequest=JsonDocument.Parse(continuation.Request);var c=continuationRequest.RootElement;
  using var retentionRequest=JsonDocument.Parse(Required(c,"retentionRequest"));var retained=retentionRequest.RootElement;
  using var interruptionRequest=JsonDocument.Parse(Required(r,"request"));var interrupted=interruptionRequest.RootElement;
  Check(Required(r,"version")=="1"&&Required(r,"requestDigest")==DigestText(Required(r,"request"))&&Required(r,"pendingDigest")==DigestText(pending)&&Required(r,"continuationId")==continuation.Id&&Required(r,"identity")==continuation.Identity&&Required(r,"state")=="applied"&&Required(r,"admission")=="closed"&&Required(r,"originalOutcome")=="not-inferred"&&Required(r,"continuationOutcome")=="not-inferred","applied predecessor receipt correlation");
  Check(Required(interrupted,"continuationRequest")==continuation.Request&&Required(interrupted,"continuationIntentDigest")==DigestText(pending)&&Required(interrupted,"expectedState")=="applied"&&Required(interrupted,"observedStateDigest")==Required(r,"stateDigest"),"interruption accepted bytes correlation");
  foreach(var entry in r.GetProperty("evidence").EnumerateObject()){
   Check(System.Text.RegularExpressions.Regex.IsMatch(entry.Name,@"\A[0-9a-f]{64}\.json\z"),"frozen storage filename");
   Check(DigestText(System.IO.File.ReadAllText(System.IO.Path.Combine(StorageRoot,entry.Name)))==entry.Value.GetString(),"frozen predecessor evidence changed");
  }
  Check(DigestText(r.GetProperty("evidence").GetRawText())==Required(r,"evidenceDigest")&&Required(interrupted,"evidenceDigest")==Required(r,"evidenceDigest"),"frozen inventory digest");
  // All predecessor slots must retain their exact terminal ownership. Custody
  // precedes Git inspection. Never change an active original/continuation slot.
  var custody=InterruptedCustody(continuation,out var last);Check(DigestText(JsonSerializer.Serialize(custody))==Required(r,"custodyDigest")&&last!=null,"predecessor custody changed");
  string originalRaw=System.IO.File.ReadAllText(StoragePath("physical-child/v1"));var original=JsonSerializer.Deserialize<GitChild>(originalRaw)!;
  Check(original.Version=="2"&&original.OwnerDigest==SupportedContinuationOwner,"original controlled ownership required");
  if(original.State=="active")LoadJoin(original,originalRaw);
  else{Check(original.State=="quiescent"&&original.ExitCode==0&&original.InputClosed&&original.OutputDrained,"original terminal custody");var active=JsonSerializer.Deserialize<GitChild>(originalRaw)!;active.State="active";active.ExitCode=null;active.InputClosed=false;active.OutputDrained=false;var witness=LoadJoin(active,JsonSerializer.Serialize(active));Check(witness.ExitCode==0&&witness.ExitSignal=="","original actual join");}
  string rawRegistry=System.IO.File.ReadAllText(StoragePath("registry/v1"));using var registryDoc=JsonDocument.Parse(rawRegistry);var registry=registryDoc.RootElement;
  Check(Required(registry,"phase")=="pending"&&Required(registry,"token")==continuation.Identity&&Required(registry,"intent")!=""&&Required(registry,"outcome")==""&&Required(registry,"outcomeSource")==""&&DigestText(rawRegistry)==continuation.RegistryDigest,"original pending registry remains exact");
  Check(!System.IO.File.Exists(StoragePath(ContinuationResultKey(continuation.Id)))&&!System.IO.File.Exists(StoragePath("outcome/"+continuation.Identity))&&!System.IO.File.Exists(StoragePath("outcome-receipt/"+continuation.Identity))&&!System.IO.File.Exists(StoragePath(AdmissionKey))&&!System.IO.File.Exists(StoragePath(ReleaseKey)),"unsupported actual outcome/release ancestor");
  string retainedAuthority=AuthorityValue(retained,"authorization"),continuedAuthority=AuthorityValue(c,"authorization"),interruptedAuthority=AuthorityValue(interrupted,"authorization");
  foreach(var item in new[]{("dispositionAuthorization",retainedAuthority),("continuationAuthorization",continuedAuthority),("interruptedContinuationAuthorization",interruptedAuthority)}){string supplied=ScenarioAuthority(item.Item1,true);Check(supplied==""||supplied==item.Item2,"current authority contradicts accepted predecessor");}
  string request=Setting("epochRequest")!=""?System.IO.File.ReadAllText(Setting("epochRequest")):System.IO.File.ReadAllText(StoragePath("epoch/v1/intent"));using var proposalDoc=JsonDocument.Parse(request);var q=proposalDoc.RootElement;
  string memberIdentity=Required(q,"memberIdentity"),integrationIdentity=Required(q,"integrationIdentity"),member=Required(registry,"next"),token="journal:"+integrationIdentity+":"+DigestText(Required(q,"integrationRequest"));
  Check(System.Text.RegularExpressions.Regex.IsMatch(memberIdentity,@"\A[0-9a-f]{64}\z")&&System.Text.RegularExpressions.Regex.IsMatch(integrationIdentity,@"\A[0-9a-f]{64}\z"),"bounded proposed storage identities");
   var allowed=r.GetProperty("evidence").EnumerateObject().Select(x=>x.Name).ToHashSet(StringComparer.Ordinal);allowed.Add(System.IO.Path.GetFileName(StoragePath(InterruptedDispositionKey)));
  allowed.Add(System.IO.Path.GetFileName(StoragePath(EpochDispositionIntent)));allowed.Add(System.IO.Path.GetFileName(StoragePath(EpochDispositionReceipt)));
  string[] admin={"epoch/v1/intent","epoch/v1/blocked","epoch/v1/result","epoch/v1/activation"};
  string[] application={"epoch-registry/v1","epoch-journal/v1/"+integrationIdentity,"registry-member/v1/"+member,"registry-admission/v1/"+memberIdentity,"outcome/"+token,"outcome-receipt/"+token};
  foreach(string key in admin.Concat(application).Concat(new[]{PlanKey(token),"physical-receipt/"+token+"/commit","physical-receipt/"+token+"/head","physical-receipt/"+token+"/save"}))allowed.Add(System.IO.Path.GetFileName(StoragePath(key)));
  foreach(string key in application){string lineage="epoch-lineage/v1/"+DigestText(key);allowed.Add(System.IO.Path.GetFileName(StoragePath(lineage)));
   if(System.IO.File.Exists(StoragePath("epoch/v1/activation"))&&System.IO.File.Exists(StoragePath(key)))Check(System.IO.File.ReadAllText(StoragePath(lineage))==System.IO.File.ReadAllText(StoragePath("epoch/v1/activation")),"application lineage differs from activation");
  }
  for(int stage=0;stage<3;stage++){string key="physical-epoch-child/v1/"+DigestText(token)+"/"+stage;allowed.Add(System.IO.Path.GetFileName(StoragePath(key)));if(System.IO.File.Exists(StoragePath(key))){var child=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath(key)))!;allowed.Add(System.IO.Path.GetFileName(StoragePath("physical-join/v1/"+child.Invocation)));}}
  Check(System.IO.Directory.GetFiles(StorageRoot).All(x=>allowed.Contains(System.IO.Path.GetFileName(x))),"unowned epoch storage appeared");
  if(!System.IO.File.Exists(StoragePath("epoch/v1/intent"))){
   Check(!System.IO.File.Exists(StoragePath(PlanKey(token))),"orphan epoch plan lacks accepted intent");
   for(int stage=0;stage<3;stage++)Check(!System.IO.File.Exists(StoragePath("physical-epoch-child/v1/"+DigestText(token)+"/"+stage)),"orphan epoch launch lacks accepted intent");
  }
  // Before epoch publication, reconstruct the predecessor receipt with its
  // original unchanged predicates. Later effects authenticate its frozen facts
  // separately; an old physical digest is never required to describe a new HEAD.
  if(!System.IO.File.Exists(StoragePath("epoch/v1/intent"))){
   // Reconstruct the old receipt under its exact accepted authority and storage
   // contract. Optional present current labels were already checked above;
   // omitted labels neither erase accepted bytes nor grant new authority.
   Check(Required(interrupted,"storageContract")==InterruptedStorageContract,"accepted predecessor storage contract");
   var acceptedSettings=scenario.EnumerateObject().ToDictionary(x=>x.Name,x=>x.Value.Clone(),StringComparer.Ordinal);
   acceptedSettings["interruptedContinuationAuthorization"]=JsonSerializer.SerializeToElement(interruptedAuthority);
   acceptedSettings["interruptedContinuationStorageContract"]=JsonSerializer.SerializeToElement(InterruptedStorageContract);
   using var acceptedScenario=JsonDocument.Parse(JsonSerializer.Serialize(acceptedSettings));
   var replay=new Effects(acceptedScenario.RootElement,"");replay.epochMode=false;
   Check(replay.RetainInterruptedContinuation(Required(r,"request"))==Required(r,"result"),"predecessor receipt reconstruction");
  }
  var physical=PhysicalState();var priorPlan=LoadPlan(continuation.Identity);string selected=Required(q,"selectedCommit");
  Check(priorPlan.Before.Objects.Split('\n').Contains(selected+" commit"),"selected candidate lacks frozen owned object provenance");
  Check(Git(new[]{"rev-parse",selected+"^{tree}"})!="","selected candidate tree unavailable");
  string state="applied";
  if(System.IO.File.Exists(StoragePath(PlanKey(token)))){
   var currentPlan=LoadPlan(token);Check(!currentPlan.NoMutation&&currentPlan.Selected==selected&&DigestText(JsonSerializer.Serialize(currentPlan.Before))==Required(r,"stateDigest"),"new intent not based on epoch baseline/selection");
   string classified=Corroborated(currentPlan,physical);
   state=classified=="applied"||classified=="absent"?"applied":"unknown";
  }else Check(DigestText(JsonSerializer.Serialize(physical))==Required(r,"stateDigest"),"current state differs from frozen applied baseline");
  return JsonSerializer.Serialize(new {state,newPlan=System.IO.File.Exists(StoragePath(PlanKey(token)))?"true":"false",predecessorDigest=DigestText(receiptRaw),inventoryDigest=Required(r,"evidenceDigest"),baselineStateDigest=Required(r,"stateDigest"),baselineHead=priorPlan.Commit,repository=GitRoot,repositoryId=Setting("fixtureId"),retentionId=Required(retained,"id"),continuationId=continuation.Id,interruptionId=Required(interrupted,"id"),retentionAuthorization=retainedAuthority,continuationAuthorization=continuedAuthority,interruptionAuthorization=interruptedAuthority,originalIdentity=Required(registry,"id").Substring("journal/v1/".Length),originalFingerprint=Required(registry,"fingerprint"),originalIntent=Required(registry,"intent"),member=registry.GetProperty("entries")[0].GetProperty("id").GetString(),next=member,selectedCommit=selected,continuationRequest=continuation.Request,continuationRequestDigest=DigestText(continuation.Request),continuationIntentDigest=DigestText(pending),custodyDigest=Required(r,"custodyDigest")});
 }

 // Mechanical raw evidence for one fully witnessed current epoch tail.
 // All acceptance, pending-result policy and publication live in the graph.
 const string EpochDispositionIntent="epoch-disposition/v1/intent",EpochDispositionReceipt="epoch-disposition/v1/receipt";
 public NyStr EpochDispositionFacts(){
  try{
   EpochOwnerPath(); // Pin before any storage access or physical inspection.
   string prior=EpochFacts();using var priorDoc=JsonDocument.Parse(prior);var facts=priorDoc.RootElement;
   string accepted=System.IO.File.ReadAllText(StoragePath("epoch/v1/intent"));using var proposal=JsonDocument.Parse(accepted);var q=proposal.RootElement;
   string integration=Required(q,"integrationRequest"),identity=Required(q,"integrationIdentity"),token="journal:"+identity+":"+DigestText(integration);
   var custody=new List<object>();
   for(int stage=0;stage<3;stage++){
    string key="physical-epoch-child/v1/"+DigestText(token)+"/"+stage;
    string launch=System.IO.File.ReadAllText(StoragePath(key));var child=JsonSerializer.Deserialize<GitChild>(launch)!;
    Check(child.State=="quiescent"&&child.Pid.HasValue,"complete quiescent epoch tail required");
    string witness=System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+child.Invocation));
    custody.Add(new {key,stage,launch,witness,launchDigest=DigestText(launch),witnessDigest=DigestText(witness)});
   }
   EpochChildGuard(); // Exact arguments, input, pinned owner and terminal captures.
   string planRaw=System.IO.File.ReadAllText(StoragePath(PlanKey(token)));var plan=LoadPlan(token);
   var physical=PhysicalState();string newEffectState=Corroborated(plan,physical);
   Check(!plan.NoMutation,"fresh mutation plan required");
   string registryRaw=System.IO.File.ReadAllText(StoragePath("epoch-registry/v1")),journalRaw=System.IO.File.ReadAllText(StoragePath("epoch-journal/v1/"+identity));
   using var registryDoc=JsonDocument.Parse(registryRaw);var registry=registryDoc.RootElement;
   Check(Required(registry,"intent")==plan.Intent,"current registry/physical plan correlation");
   using var intentDoc=JsonDocument.Parse(plan.Intent);var intent=intentDoc.RootElement;
   string member=intent.GetProperty("target").GetInt64().ToString(System.Globalization.CultureInfo.InvariantCulture);
   var entry=registry.GetProperty("entries").EnumerateArray().Single(x=>Required(x,"id")==member);
   Check(Required(entry,"base")==Required(q,"baselineHead")&&Required(entry,"commit")==plan.Selected&&Required(entry,"integrated")=="","current Member physical selection correlation");
   // Complete current inventory excludes only this separate decision's two files.
   // Sorting fixes receipt bytes and exact replay, never repairs old evidence.
   var inventory=new SortedDictionary<string,string>(StringComparer.Ordinal);
   foreach(string path in System.IO.Directory.GetFiles(StorageRoot)){
    if(path==StoragePath(EpochDispositionIntent)||path==StoragePath(EpochDispositionReceipt))continue;
    inventory.Add(System.IO.Path.GetFileName(path),DigestText(System.IO.File.ReadAllText(path)));
   }
   string inventoryRaw=JsonSerializer.Serialize(inventory),custodyRaw=JsonSerializer.Serialize(custody,new JsonSerializerOptions{Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping});
   var output=facts.EnumerateObject().ToDictionary(x=>x.Name,x=>x.Value.Clone(),StringComparer.Ordinal);
   void Add(string key,string value)=>output[key]=JsonSerializer.SerializeToElement(value);
   foreach(var pair in new[]{("epochRequest",accepted),("activation",System.IO.File.ReadAllText(StoragePath("epoch/v1/activation"))),("blocked",System.IO.File.ReadAllText(StoragePath("epoch/v1/blocked"))),("originalRegistry",System.IO.File.ReadAllText(StoragePath("registry/v1"))),("registry",registryRaw),("journal",journalRaw),("plan",planRaw),("custody",custodyRaw),("inventory",inventoryRaw),("epochFacts",prior),("integrationRequest",integration),("integrationIdentity",identity),("integrationTypedId",JsonDocument.Parse(integration).RootElement.GetProperty("id").GetRawText()),("effectIdentity",token),("member",member),("next",Required(registry,"next")),("fingerprint",Required(registry,"fingerprint")),("intent",plan.Intent),("newEffectState",newEffectState),("currentStateDigest",DigestText(JsonSerializer.Serialize(physical))),("allNewSlots","quiescent"),("blockedDigest",DigestText(System.IO.File.ReadAllText(StoragePath("epoch/v1/blocked")))),("registryDigest",DigestText(registryRaw)),("journalDigest",DigestText(journalRaw)),("planDigest",DigestText(planRaw)),("custodyDigest",DigestText(custodyRaw)),("inventoryDigest",DigestText(inventoryRaw))})Add(pair.Item1,pair.Item2);
   string current=ScenarioAuthority("epochAuthorization",true);Check(current==""||current==AuthorityValue(q,"authorization"),"current epoch authority contradicts accepted bytes");
   Observe(new {operation="epoch-disposition-facts",newEffectState,currentStateDigest=output["currentStateDigest"].GetString()});
   return JsonSerializer.Serialize(output);
  }catch(Exception error){Observe(new {operation="epoch-disposition-inspection-rejected",reason=error.Message});return "{unavailable}";}
 }

 // Mechanical storage, provenance, custody and physical comparison only.
 // The graph accepts authority and requests, publishes and dispatches policy.
 bool additionalMode;
 string AdditionalToken(JsonElement q)=>"journal:"+Required(q,"integrationIdentity")+":"+DigestText(Required(q,"integrationRequest"));
 void AdditionalChildGuard(){
  string path=StoragePath("additional/v1/intent");if(!System.IO.File.Exists(path))return;
  // The same pinned three-stage verifier is reused with an explicit namespace.
  EpochChildGuardFor("additional/v1/intent","physical-epoch-child/v1/");
 }
 public NyStr AdditionalFacts(){try{return InspectAdditional();}catch(Exception error){Observe(new {operation="additional-inspection-rejected",reason=error.Message});return "{unavailable}";}}
 string InspectAdditional(){
  EpochOwnerPath(); // Before storage or physical inspection, even on refusal.
  Check(additionalMode&&Setting("evidence")!="unavailable"&&Setting("physicalControl")==""&&Setting("worktreeModeControl")=="","enabled additional inspection required");
  string receiptRaw=System.IO.File.ReadAllText(StoragePath(EpochDispositionReceipt)),requestRaw=System.IO.File.ReadAllText(StoragePath(EpochDispositionIntent));
  using var receiptDoc=JsonDocument.Parse(receiptRaw);var r=receiptDoc.RootElement;
  using var decisionDoc=JsonDocument.Parse(requestRaw);var disposition=decisionDoc.RootElement;
  Check(Required(r,"request")==requestRaw&&Required(r,"requestDigest")==DigestText(requestRaw),"complete predecessor receipt required");
  foreach(string name in new[]{"originalOutcome","continuationOutcome","freshOutcome"})Check(Required(r,name)=="unknown","three retained unknowns required");
  Check(Required(r,"admission")=="closed"&&Required(r,"newEffectState")=="applied","closed applied predecessor required");
  string acceptedRaw=Required(r,"epochRequest");using var acceptedDoc=JsonDocument.Parse(acceptedRaw);var accepted=acceptedDoc.RootElement;
  Check(acceptedRaw==System.IO.File.ReadAllText(StoragePath("epoch/v1/intent")),"accepted epoch bytes changed");
  using var inventoryDoc=JsonDocument.Parse(Required(r,"inventory"));var inventory=inventoryDoc.RootElement;
  foreach(var item in inventory.EnumerateObject()){
   Check(System.Text.RegularExpressions.Regex.IsMatch(item.Name,@"\A[0-9a-f]{64}\.json\z"),"frozen inventory name");
   Check(DigestText(System.IO.File.ReadAllText(System.IO.Path.Combine(StorageRoot,item.Name)))==item.Value.GetString(),"frozen evidence changed");
  }
  // Retained original/continuation launches remain terminal. Late witnesses do
  // not remove an active launch fence, and no old owner/provider is restarted.
  var original=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath("physical-child/v1")))!;
  Check(original.Version=="2"&&original.OwnerDigest==SupportedContinuationOwner&&original.State=="quiescent"&&original.Pid.HasValue&&original.ExitCode==0&&original.InputClosed&&original.OutputDrained,"original quiescent pinned custody required");
  var originalActive=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath("physical-child/v1")))!;originalActive.State="active";originalActive.ExitCode=null;originalActive.InputClosed=false;originalActive.OutputDrained=false;
  var originalJoin=LoadJoin(originalActive,JsonSerializer.Serialize(originalActive));Check(originalJoin.ExitCode==0&&originalJoin.ExitSignal=="","original terminal witness required");
  var continuation=JsonSerializer.Deserialize<ContinuationIntent>(System.IO.File.ReadAllText(StoragePath(ContinuationKey)))!;
  var oldCustody=InterruptedCustody(continuation,out var last);Check(last!=null,"continuation custody required");
  for(int stage=0;stage<2;stage++){var child=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath("physical-continuation-child/v1/"+continuation.Id+"/"+stage)))!;Check(child.State=="quiescent"&&child.Pid.HasValue&&child.OwnerDigest==SupportedContinuationOwner&&child.ExitCode==0&&child.InputClosed&&child.OutputDrained,"continuation quiescent custody required");}
  EpochChildGuard();string oldToken=AdditionalToken(accepted);var oldPlan=LoadPlan(oldToken);
  var custody=new List<object>();for(int stage=0;stage<3;stage++){
   string key="physical-epoch-child/v1/"+DigestText(oldToken)+"/"+stage,launch=System.IO.File.ReadAllText(StoragePath(key));var child=JsonSerializer.Deserialize<GitChild>(launch)!;string witness=System.IO.File.ReadAllText(StoragePath("physical-join/v1/"+child.Invocation));custody.Add(new {key,stage,launch,witness,launchDigest=DigestText(launch),witnessDigest=DigestText(witness)});
  }
  string custodyRaw=JsonSerializer.Serialize(custody,new JsonSerializerOptions{Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping});Check(custodyRaw==Required(r,"custody"),"frozen epoch custody changed");
  string proposalRaw=Setting("additionalRequest")!=""?System.IO.File.ReadAllText(Setting("additionalRequest")):System.IO.File.Exists(StoragePath("additional/v1/intent"))?System.IO.File.ReadAllText(StoragePath("additional/v1/intent")):"{}";
  using var proposalDoc=JsonDocument.Parse(proposalRaw);var q=proposalDoc.RootElement;
  string token=q.TryGetProperty("integrationIdentity",out _)?AdditionalToken(q):"",memberIdentity=q.TryGetProperty("memberIdentity",out var mid)?mid.GetString()??"":"";
  if(token!="")Check(System.Text.RegularExpressions.Regex.IsMatch(Required(q,"integrationIdentity"),@"\A[0-9a-f]{64}\z")&&System.Text.RegularExpressions.Regex.IsMatch(memberIdentity,@"\A[0-9a-f]{64}\z"),"bounded additional identities");
  bool newPlan=token!=""&&System.IO.File.Exists(StoragePath(PlanKey(token)));var physical=PhysicalState();GitState baseline=physical;
  if(newPlan){AdditionalChildGuard();var plan=LoadPlan(token);baseline=plan.Before;Check(!plan.NoMutation&&plan.Selected==Required(q,"selectedCommit"),"additional plan selection");string state=Corroborated(plan,physical);Check(state=="absent"||state=="applied","additional physical state unresolved");}
  Check(DigestText(JsonSerializer.Serialize(baseline))==Required(r,"currentStateDigest")&&Corroborated(oldPlan,baseline)=="applied","predecessor baseline no longer exact applied state");
  var allowed=inventory.EnumerateObject().Select(x=>x.Name).ToHashSet(StringComparer.Ordinal);foreach(string k in new[]{EpochDispositionIntent,EpochDispositionReceipt})allowed.Add(System.IO.Path.GetFileName(StoragePath(k)));
  string next=Required(r,"next");
  if(token!=""){
   if(!System.IO.File.Exists(StoragePath("additional/v1/activation"))){foreach(string k in new[]{"additional-journal/v1/"+Required(q,"integrationIdentity"),"additional-member/v1/"+next,"additional-admission/v1/"+memberIdentity,"outcome/"+token,"outcome-receipt/"+token,"physical-receipt/"+token+"/commit","physical-receipt/"+token+"/head","physical-receipt/"+token+"/save"})Check(!System.IO.File.Exists(StoragePath(k))&&!System.IO.File.Exists(StoragePath("additional-lineage/v1/"+DigestText(k))),"application evidence before additional activation");Check(!newPlan,"physical plan before additional activation");}
   // A physical plan is durable before any integration journal/result/receipt
   // or its graph lineage can be published. Orphans cannot become replay facts.
   if(!newPlan)foreach(string k in new[]{"additional-journal/v1/"+Required(q,"integrationIdentity"),"outcome/"+token,"outcome-receipt/"+token,"physical-receipt/"+token+"/commit","physical-receipt/"+token+"/head","physical-receipt/"+token+"/save"})Check(!System.IO.File.Exists(StoragePath(k))&&!System.IO.File.Exists(StoragePath("additional-lineage/v1/"+DigestText(k))),"integration evidence lacks predecessor physical plan");
   string[] admin={"additional/v1/intent","additional/v1/blocked","additional/v1/result","additional/v1/activation"};
   string[] app={"additional-registry/v1","additional-journal/v1/"+Required(q,"integrationIdentity"),"additional-member/v1/"+next,"additional-admission/v1/"+memberIdentity,"outcome/"+token,"outcome-receipt/"+token};
   foreach(string k in admin.Concat(app).Concat(new[]{PlanKey(token),"physical-receipt/"+token+"/commit","physical-receipt/"+token+"/head","physical-receipt/"+token+"/save"}))allowed.Add(System.IO.Path.GetFileName(StoragePath(k)));
   foreach(string k in app){string lineage="additional-lineage/v1/"+DigestText(k);allowed.Add(System.IO.Path.GetFileName(StoragePath(lineage)));if(System.IO.File.Exists(StoragePath("additional/v1/activation"))&&(System.IO.File.Exists(StoragePath(k))||System.IO.File.Exists(StoragePath(lineage))))Check(System.IO.File.ReadAllText(StoragePath(lineage))==System.IO.File.ReadAllText(StoragePath("additional/v1/activation")),"additional application lineage changed");}
   for(int stage=0;stage<3;stage++){string k="physical-epoch-child/v1/"+DigestText(token)+"/"+stage;allowed.Add(System.IO.Path.GetFileName(StoragePath(k)));if(System.IO.File.Exists(StoragePath(k))){var child=JsonSerializer.Deserialize<GitChild>(System.IO.File.ReadAllText(StoragePath(k)))!;allowed.Add(System.IO.Path.GetFileName(StoragePath("physical-join/v1/"+child.Invocation)));}}
   if(!System.IO.File.Exists(StoragePath("additional/v1/intent"))){Check(!newPlan,"orphan additional plan");for(int stage=0;stage<3;stage++)Check(!System.IO.File.Exists(StoragePath("physical-epoch-child/v1/"+DigestText(token)+"/"+stage)),"orphan additional launch");}
   if(System.IO.File.Exists(StoragePath("additional-registry/v1"))){using var currentRegistry=JsonDocument.Parse(System.IO.File.ReadAllText(StoragePath("additional-registry/v1")));if(Required(currentRegistry.RootElement,"phase")!="idle")Check(newPlan,"pending/actual additional registry lacks physical plan");}
   if(newPlan){using var regDoc=JsonDocument.Parse(System.IO.File.ReadAllText(StoragePath("additional-registry/v1")));var reg=regDoc.RootElement;if(Required(reg,"phase")=="ready"){var plan=LoadPlan(token);Check(Required(reg,"intent")==plan.Intent&&Required(reg,"token")==token&&Corroborated(plan,physical)=="applied","ready result physical correlation");var entry=reg.GetProperty("entries").EnumerateArray().Single(x=>Required(x,"id")==next);Check(Required(entry,"integrated")==plan.Commit,"ready Member actual HEAD correlation");}}
  }
  Check(System.IO.Directory.GetFiles(StorageRoot).All(x=>allowed.Contains(System.IO.Path.GetFileName(x))),"unowned additional storage appeared");
  // Candidate provenance comes only from the original immutable object inventory.
  var continuationPlan=LoadPlan(continuation.Identity);string selected=q.TryGetProperty("selectedCommit",out var choice)?choice.GetString()??"":"";
  if(selected!="")Check(continuationPlan.Before.Objects.Split('\n').Contains(selected+" commit")&&Git(new[]{"rev-parse",selected+"^{tree}"})!="","additional candidate lacks frozen owned provenance");
  using var epochFactsDoc=JsonDocument.Parse(Required(r,"epochFacts"));var prior=epochFactsDoc.RootElement.EnumerateObject().ToDictionary(x=>x.Name,x=>x.Value.Clone(),StringComparer.Ordinal);
  void AddPrior(string k,string v)=>prior[k]=JsonSerializer.SerializeToElement(v);
  foreach(var item in r.EnumerateObject())if(item.Value.ValueKind==JsonValueKind.String)AddPrior(item.Name,item.Value.GetString()!);
  foreach(var item in disposition.EnumerateObject())if(item.Value.ValueKind==JsonValueKind.String&&!new[]{"id","authorization","action","scope"}.Contains(item.Name))AddPrior(item.Name,item.Value.GetString()!);
  AddPrior("inventoryDigest",DigestText(Required(r,"inventory")));AddPrior("custodyDigest",DigestText(custodyRaw));AddPrior("allNewSlots","quiescent");
  foreach(var pair in new[]{("blockedDigest",Required(r,"blocked")),("registryDigest",Required(r,"registry")),("journalDigest",Required(r,"journal")),("planDigest",Required(r,"plan"))})AddPrior(pair.Item1,DigestText(pair.Item2));
  string dispositionAuthority=AuthorityValue(disposition,"authorization"),epochAuthority=AuthorityValue(accepted,"authorization");
  foreach(var pair in new[]{("epochDispositionAuthorization",dispositionAuthority),("epochAuthorization",epochAuthority),("dispositionAuthorization",Required(epochFactsDoc.RootElement,"retentionAuthorization")),("continuationAuthorization",Required(epochFactsDoc.RootElement,"continuationAuthorization")),("interruptedContinuationAuthorization",Required(epochFactsDoc.RootElement,"interruptionAuthorization"))}){string supplied=ScenarioAuthority(pair.Item1,true);Check(supplied==""||supplied==pair.Item2,"ancestor authority label contradicts accepted bytes");}
  var reserved=new List<string>{Required(disposition,"id"),Required(accepted,"id"),Required(accepted,"epoch"),Required(r,"effectIdentity"),Required(accepted,"memberIdentity"),Required(accepted,"integrationIdentity"),Required(epochFactsDoc.RootElement,"retentionId"),Required(epochFactsDoc.RootElement,"continuationId"),Required(epochFactsDoc.RootElement,"interruptionId"),Required(epochFactsDoc.RootElement,"originalIdentity")};
  foreach(string name in new[]{"originalRequest","memberRequest","integrationRequest"}){using var frame=JsonDocument.Parse(Required(accepted,name));var id=frame.RootElement.GetProperty("id");reserved.Add(id.ValueKind==JsonValueKind.String?id.GetString()!:id.GetRawText());}
  return JsonSerializer.Serialize(new {predecessor=receiptRaw,predecessorRequest=requestRaw,priorFacts=JsonSerializer.Serialize(prior),sourceRegistry=Required(r,"registry"),originalBlocked=Required(r,"blocked"),continuationRequest=Required(epochFactsDoc.RootElement,"continuationRequest"),freshRequest=Required(accepted,"integrationRequest"),originalRequest=Required(accepted,"originalRequest"),predecessorDigest=DigestText(receiptRaw),inventoryDigest=DigestText(Required(r,"inventory")),custodyDigest=DigestText(custodyRaw),baselineStateDigest=Required(r,"currentStateDigest"),baselineHead=oldPlan.Commit,repository=GitRoot,repositoryId=Setting("fixtureId"),next,selectedCommit=selected,newPlan=newPlan?"true":"false",originalIdentity=Required(epochFactsDoc.RootElement,"originalIdentity"),reservedIds=reserved,wireFrames=new[]{Required(accepted,"originalRequest"),Required(accepted,"memberRequest"),Required(accepted,"integrationRequest")},authorities=new[]{dispositionAuthority,epochAuthority,Required(epochFactsDoc.RootElement,"retentionAuthorization"),Required(epochFactsDoc.RootElement,"continuationAuthorization"),Required(epochFactsDoc.RootElement,"interruptionAuthorization")}});
 }

 public NyResult<NyUnit,NyStr> Op_30316131336339322D316337632D373230332D383631392D613636353063363634623663() => Open();
public NyUnit Op_30316131336339322D316337632D373765652D393835372D636563613439376138376131(NyUnit handle) => Close(handle);
public NyResult<NyUnit,NyStr> Op_30316131336339322D316337632D373833362D626634362D633466373264313366326465(NyStr workspace,NyStr basis) => WorkspaceCreate(workspace,basis);
public NyResult<NyUnit,NyStr> Op_30316131336339322D316337632D373133372D393736332D313232353437303961363137(NyStr workspace) => WorkspaceDiscard(workspace);
public NyResult<NyStr,NyStr> Op_30316131336339322D316337632D373163372D393231312D336634303537366663666337(long id,NyStr workspace,long previous) => Provider(id,workspace,previous);
public NyUnit Op_30316131336339322D316337632D373032312D613939382D626332653233373666653734(long id) => MemberClose(id);
public NyResult<NyStr,NyStr> Op_30316131336339322D316337632D373433322D383430342D303632383866356462633330(long id,NyStr workspace) => Snapshot(id,workspace);
public NyStr Op_30316131336339322D316337632D373835632D626533392D656165636564303965623535(long id,NyStr commit) => Checks(id,commit);
public NyUnit Op_30316131336339322D316337632D373630382D383938332D356132663035303063646165(NyStr label) => Gate(label);
public NyUnit Op_30316131336339322D316337632D373163392D613661622D346661356161623938306531(NyStr label,NyStr record) => Reply(label,record);
public NyResult<NyList<NyStr>,NyStr> Op_30316131336339322D316337632D373961612D616566342D633837666235613566383035(NyStr operation,NyStr patch) => Step(operation,patch);
public NyOption<NyStr> Op_30316131336339322D316337632D373762362D383130372D356539633561323531333263(NyStr key) => StorageRead(key);
public NyUnit Op_30316131336339322D316337632D373839302D383833332D336435326431343236393437(NyStr key,NyStr value) => StorageWrite(key,value);
public NyStr Op_30316131336339322D316337632D376561622D616161332D363465323066656566666236(NyStr value) => Digest(value);
public NyUnit Op_30316131336339322D316337632D376661312D393365322D616331616437316566383432(NyStr identity) => EffectIdentity(identity);
public NyStr Op_30316131336339322D316337632D373561632D393730302D663331616236303735643063(NyStr identity) => EffectEvidence(identity);
public bool Op_30316131336339322D316337632D376566302D396537322D613431303861633336623338() => StorageEmpty();
public NyStr Op_30316131336339322D316337632D373366342D396332392D643136336433626137383662(NyStr key) => FixtureRead(key);
public NyStr Op_30316131336339322D316337632D373962312D613063362D616533306635633037316566() => PhysicalFacts();
public NyStr Op_30316131336339322D316337632D376264312D396565382D616135373631666565383738() => EpochDispositionFacts();
public NyStr Op_30316131336339322D316337632D373262312D396135622D353563373062343761356537() => AdditionalFacts();
}
// Linux offline pipe binding: no pending Console read is abandoned at shutdown.
// The graph owns the reader task and framing handoff; this host owns syscalls.
static class UnixPipe
{
 [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
 struct PollFd {public int fd;public short events,revents;}
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int poll(ref PollFd fd,uint count,int timeout);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern nint read(int fd,byte[] bytes,nuint count);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern nint write(int fd,byte[] bytes,nuint count);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int fcntl(int fd,int command,int flags);
 [System.Runtime.InteropServices.DllImport("libc",SetLastError=true)] static extern int close(int fd);
 public const int TickMs=25,WriteDeadlineMs=250;
 public static void Nonblocking(int fd){int flags=fcntl(fd,3,0);if(flags<0||fcntl(fd,4,flags|2048)<0)throw Fault("fcntl");}
 public static void CloseInput(){if(close(0)<0)throw Fault("close input");}
 static System.IO.IOException Fault(string op)=>new(op+" errno="+System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
 static void Ready(int fd,short events,CancellationToken token,System.Diagnostics.Stopwatch? deadline=null)
 {
  while(true){
   if(token.IsCancellationRequested)throw new System.Threading.Tasks.TaskCanceledException("pipe read cancelled");
   if(deadline?.ElapsedMilliseconds>=WriteDeadlineMs)throw new TimeoutException("pipe write deadline");
   var item=new PollFd{fd=fd,events=events};int n=poll(ref item,1,TickMs);
   if(n>0)return;
   if(n<0&&System.Runtime.InteropServices.Marshal.GetLastPInvokeError()!=4)throw Fault("poll");
  }
 }
 public static int Read(byte[] bytes,int count,CancellationToken token){
  while(true){Ready(0,1,token);int n=(int)read(0,bytes,(nuint)count);if(n>=0)return n;int e=System.Runtime.InteropServices.Marshal.GetLastPInvokeError();if(e!=4&&e!=11)throw Fault("read");}
 }
 public static void Write(string line){
  byte[] bytes=System.Text.Encoding.UTF8.GetBytes(line+"\n");int offset=0;
  var clock=System.Diagnostics.Stopwatch.StartNew();
  while(offset<bytes.Length){
   Ready(1,4,CancellationToken.None,clock);
   // Nonblocking write can be partial; retain exact accepted-byte observations.
   var remaining=bytes.AsSpan(offset).ToArray();int n=(int)write(1,remaining,(nuint)remaining.Length);
   if(n>0){Effects.Observe(new {operation="pipe-write",hex=Convert.ToHexString(remaining.AsSpan(0,n))});offset+=n;continue;}
   int e=System.Runtime.InteropServices.Marshal.GetLastPInvokeError();if(n<0&&(e==4||e==11))continue;throw Fault("write");
  }
 }
}
// Generic bounded line capability. No command parsing, admission or team state.
sealed class Pipe : NyC_30316131336339322D373432662D373033662D393536322D326335353666623861303336, IDisposable
{
 const int ReadBufferBytes=1024,MaximumSupportedLimit=2*1024*1024;
 readonly byte[] pending=new byte[ReadBufferBytes];
 readonly System.Text.UTF8Encoding utf8=new(false,true);
 readonly Effects effects;readonly string control;
 public Exception? Failure;
 int position,available,activeReads;bool skipLf,eof,closed;
 public Pipe(Effects effects,string control){this.effects=effects;this.control=control;UnixPipe.Nonblocking(0);}
 int NextByte(int bufferedBytes){
  if(NyRuntime.CancellationRequested)throw new System.Threading.Tasks.TaskCanceledException("pipe read cancelled");
  if(position==available){
   if(eof)return -1;
   Effects.Observe(new {operation="input-wait",bufferedBytes});
   available=UnixPipe.Read(pending,pending.Length,NyRuntime.Cancellation.Value);position=0;
   Effects.Observe(new {operation="pipe-read",hex=Convert.ToHexString(pending.AsSpan(0,available)),synchronous=true});
   if(available==0){eof=true;return -1;}
  }
  return pending[position++];
 }
 public NyOption<NyStr> Op_30316131336339322D373432662D373733612D393763642D643530346237636139396238(long cp_30316131336339322D373432662D373535372D386562662D343236343139623233353566)=>ReadLine(cp_30316131336339322D373432662D373535372D386562662D343236343139623233353566);
 NyOption<NyStr> ReadLine(long maxBytes){
  Interlocked.Increment(ref activeReads);
  int length=0;
  try{
   Effects.Observe(new {operation="read-start",maxBytes});
   if(maxBytes<1||maxBytes>MaximumSupportedLimit)throw new ArgumentOutOfRangeException(nameof(maxBytes));
   byte[] frame=new byte[(int)maxBytes];
   bool tail=false;
   while(true){
    int value=NextByte(length);
    if(skipLf){skipLf=false;if(value==10)continue;}
    if(value<0){if(length==0){effects.InputEnded();return NyOption<NyStr>.None();}tail=true;break;}
    if(value==13){skipLf=true;break;}
    if(value==10)break;
    if(length==maxBytes){
     Effects.Observe(new {operation="input-oversize",maxBytes,bufferedBytes=length,observedPayloadBytes=(long)length+1,readBufferBytes=ReadBufferBytes});
     throw new System.IO.InvalidDataException("pipe frame exceeds byte limit");
    }
    frame[length++]=(byte)value;
   }
   if(control=="unrelated-input-fault"){Effects.Observe(new {operation="unrelated-input-fault"});throw new NotSupportedException("unrelated input fault");}
   Effects.Observe(new {operation="decode-start",payloadBytes=length,maxBytes,tail});
   string line=utf8.GetString(frame,0,length);
   Effects.Observe(new {operation="readLine",line});
   return NyOption<NyStr>.Some(line);
  }catch(Exception error){Failure=error;throw;}finally{Interlocked.Decrement(ref activeReads);Effects.Observe(new {operation="read-ended",activeReads=Volatile.Read(ref activeReads),bufferedBytes=length});}
 }
 public void Dispose(){
  if(closed)return;
  Effects.Check(activeReads==0,"graph must join its reader before pipe close");
  UnixPipe.CloseInput();closed=true;Effects.Observe(new {operation="input-fd-closed"});Effects.Observe(new {operation="transport-close",activeReads});
 }
}
static class Program
{
 public static void Main(string[] args){
  if(!OperatingSystem.IsLinux())throw new PlatformNotSupportedException("offline Unix pipe fixture requires Linux");
  ThreadPool.SetMinThreads(16,16);UnixPipe.Nonblocking(1);
  using var scenario=JsonDocument.Parse(System.IO.File.ReadAllText(args[0]));
  string control=args.Length>1?args[1]:"";
  var effects=new Effects(scenario.RootElement,control);var pipe=new Pipe(effects,control);
  using var lifetime=new CancellationTokenSource();NyRuntime.Cancellation.Value=lifetime.Token;
  using var signal=System.Runtime.InteropServices.PosixSignalRegistration.Create(System.Runtime.InteropServices.PosixSignal.SIGTERM,context=>{
   context.Cancel=true;Effects.Observe(new {operation="transport-cancel"});lifetime.Cancel();effects.ReleaseGates();
  });
  try{
   var result=NyFunctions.NyF_30316131336339322D386531362D373765352D396266622D376330326538353131376131(p_30316131336339322D386531362D373164382D623431362D316563393963656162646365:effects,p_30316131336339322D386531362D373832372D393066372D366662376136313739363832:pipe,p_30316131336339322D386531362D376661322D393430652D373830366366666339646165:false);
   Effects.Observe(new {operation="outcome",ok=true,isOk=result.IsOk,value=result.IsOk?result.OkValue.ToString():result.ErrorValue.ToString(),effects.Opened,effects.Closed,effects.Active,effects.LocalCompleted,effects.TerminalWritten,effects.OutputFault});
  }catch(Exception error){
   Effects.Observe(new {operation="outcome",ok=false,type=error.GetType().Name,message=error.Message,readerFaultIdentity=ReferenceEquals(error,pipe.Failure),readerFaultStack=error.StackTrace?.Contains("Pipe.ReadLine")==true,effects.Opened,effects.Closed,effects.Active,effects.LocalCompleted,effects.TerminalWritten,effects.OutputFault});
  }
  pipe.Dispose();Effects.Observe(new {operation="process-terminal"});
 }
}
